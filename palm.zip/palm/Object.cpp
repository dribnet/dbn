class Object {
public:
  Boolean equals(Object& a, Object& b) {
    return (a == b);
  }
};
