class Hashtable {
  put(Object& attribute, Object& value) {
  }

  get(Object& attribute) {
  }
};
