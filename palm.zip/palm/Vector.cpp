class Vector {
  const Int16 INITIAL_CAPACITY;

  Void** what;
  Int16 count;
  Int16 alloc;
};


Vector::Vector() {
  count = 0;
  alloc = INITIAL_CAPACITY;
  what = new Void*[alloc];
}

Vector::~Vector() {
}


Vector::add(Void& what) {
  allocCheck(count+1);
  
}


Vector& operator[](Int32 index) {
  // if this exceeds max capacity, realloc
}

// will assignment automatically work?
