#ifndef DBN_H
#define DBN_H

/*
#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

//#ifndef boolean
//typedef Short boolean
//#endif
*/

#ifndef null
#define null NULL
#endif

#endif
