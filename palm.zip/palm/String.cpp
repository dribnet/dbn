class String {
  Char *data;
  WChar *unpacked;
  Word length;

  String(char *input);
  ~String(); // destroy storage

  Int32 length() const;
};

int cstrlen(char *what) {
  int index = 0;
  char c;
  while ((c = *what++) != 0)
    index++;
  return index;
}



String::String() {
  data = NULL;
  unpacked = NULL;
  length = 0;
}


String::String(const char *input) {
  length = cstrlen(input);

  data = (Char*) MemPtrNew(length);
  Char *p = data;
  while ((*p++ = *input++) != 0) { }
  
  unpacked = (WChar*) MemPtrNew(length * sizeof(WChar));
  WChar *p = data;
  while ((*p++ = *input++) != 0) { }
}


WChar String::operator[](int offset) {
  return charAt(offset);
}



WChar String::charAt(int offset) {
  return *((Ulong)unpacked + offset*sizeof(WChar));
}


// should be handled by constructor + friend function
//boolean String::equals(char *what) {  
//}

Boolean String::equals(String& what) {
  //return TxtCompare(str, str.length(), what, what.
  return StrCmp(str, what);
}


Int32 String::length() {
  return length;
}


// friend functions

String operator+(const String& another) {
}


String operator+(const char* another) {
}
