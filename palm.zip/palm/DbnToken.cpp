class DbnToken {
  const Int16 EOL            = 0;
  const Int16 NUMBER         = 1;
  const Int16 NAME           = 2;
  const Int16 PIXEL          = 3;
  const Int16 VARIABLE       = 4;
  const Int16 BLOCK          = 5;
  const Int16 VALUE          = 6;
  const Int16 MATH           = 7;
  const Int16 STACK_VARIABLE = 8;

  const Int16 ADD      = 10;
  const Int16 SUBTRACT = 11;
  const Int16 MULTIPLY = 12;
  const Int16 DIVIDE   = 13;
  const Int16 OPERATOR = 14;
  const Int16 MODULO   = 15;

  const Int16 INPUT_CONNECTOR  = 20;
  const Int16 OUTPUT_CONNECTOR = 21;

  const Int16 COMMAND_DEF  = 30;
  const Int16 FUNCTION_DEF = 31;
  const Int16 RETURN_VALUE = 32;
  const Int16 COMMAND      = 33;
  const Int16 FUNCTION     = 34;

  const Int16 REPEAT  = 40;
  const Int16 FOREVER = 41;

  const Int16 SET       = 50;
  const Int16 PAPER     = 51;
  const Int16 PEN       = 52;
  const Int16 LINE      = 53;
  const Int16 FIELD     = 54;
  const Int16 PAUSE     = 55;
  const Int16 ANTIALIAS = 56;
  const Int16 REFRESH   = 57;
  const Int16 NOREFRESH = 58;

  const Int16 SMALLER     = 60;
  const Int16 NOT_SMALLER = 61;
  const Int16 SAME        = 62;
  const Int16 NOT_SAME    = 63;

  const Int16 ROOT        = 70;
  const Int16 STATEMENT   = 71;
  const Int16 STATEMENTS  = 72;

  Int16 kind;
  String& name;
  Int16 number;

  DbnToken& parent;

  //Int16 childCount;
  //Int16 childAlloc;
  //DbnToken **children;
  Vector& children;

  // root has globals, functions have locals, repeat has var
  Hashtable& variables;

  // only root has functions, null everywhere else
  Hashtable& functions;


  DbnToken(Int16 ikind) {
    setup(ikind, null, 0);
  }

  DbnToken(Int16 ikind, String& iname) {
    setup(ikind, iname, 0);
  }

  DbnToken(Int16 ikind, Int16 inumber) {
    kind = ikind;
    name = null;
    number = inumber;
  }

  void setup(Int16 ikind, String& iname, Int16 inumber) {
    kind = ikind;
    name = null;
    number = inumber;
    
    parent = null;
    children = null;
    variables = null;
    functions = null;
  }

  void addChild(DbnToken& newbie) {
    if (children == null) {
      children = new Vector(10);
    }
    newbie.parent = *this;
    //children[childCount++] = newbie;
    children.add(newbie);
  }

  DbnToken addChild(Int16 kind) {
    DbnToken newbie = new DbnToken(kind);
    addChild(newbie);
    return newbie;
  }

  DbnToken addChild(Int16 kind, String& name) {
    DbnToken newbie = new DbnToken(kind, name);
    addChild(newbie);
    return newbie;
  }

  DbnToken addChild(Int16 kind, Int16 number) {
    DbnToken newbie = new DbnToken(kind, number);
    addChild(newbie);
    return newbie;
  }


  DbnToken addVariable(String title) {
    if (variables == null) variables = new Hashtable();

    // this will store the value for the execution engine
    DbnToken& newbie = new DbnToken(VARIABLE, title);
    variables.put(title, newbie);
    return newbie;
  }


  DbnToken findVariable(String name) {
    if (variables != null) {
      DbnToken guess = (DbnToken) variables.get(name);
      if (guess != null) return guess;
    }
    return (parent != null) ? parent.findVariable(name) : null;
  }


  DbnToken findFunction(String name) {
    if (functions != null) {
      DbnToken guess = (DbnToken) functions.get(name);
      if (guess != null) return guess;
    }
    return (parent != null) ? parent.findFunction(name) : null;
  }
}
