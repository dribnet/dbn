/*******************************************************************
 *
 *  Copyright(c) 1997, Palm Computing Inc., All Rights Reserved  
 *
 *-------------------------------------------------------------------
 * FileName:
 *		MemoMain.h
 *
 * Description:
 *		Include file the Memo application
 *  
 *
 * History:
 *   	9/27/95 Created by Christopher Raff
 *
 *******************************************************************/

#ifndef 	__MEMOMAIN_H__
#define	__MEMOMAIN_H__

#include <IMCUtils.h>
#include <ExgMgr.h>

#define memoDBName						"MemoDB"
#define memoDBType						'DATA'
#define memoMaxLength					4096		// note: must be same as tFLD 1109 max length!!!


/************************************************************
 * Function Prototypes
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


// From MemoTransfer.c
extern void MemoSendRecord (DmOpenRef dbP, Int recordNum);

extern void MemoSendCategory (DmOpenRef dbP, Word categoryNum);

extern Err MemoReceiveData(DmOpenRef dbP, ExgSocketPtr exgSocketP);

extern Boolean MemoImportMime(DmOpenRef dbP, VoidPtr inputStream, GetCharF inputFunc,
	Boolean obeyUniqueIDs, Boolean beginAlreadyRead);

extern void MemoExportMime(DmOpenRef dbP, Int index, MemoDBRecordType *recordP, 
	const VoidPtr outputStream, const PutStringF outputFunc, 
	Boolean writeUniqueIDs, Boolean outputMimeInfo);

#ifdef __cplusplus 
}
#endif

#endif	//	__MEMOMAIN_H__

