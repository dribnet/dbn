/***********************************************************************
 *
 *	 Copyright (c) 1994-1999 3Com Corporation or its subsidiaries.
 *   All rights reserved.
 *
 * PROJECT:  Memopad
 * FILE:     MemoMain.c
 * AUTHOR:	 Art Lamb: Feb 21, 1995
 *
 * DECLARER: Memo
 *
 * DESCRIPTION:
 *	  This is the Memo application's main module.  This module
 *   starts the application, dispatches events, and stops
 *   the application. 
 *
 **********************************************************************/

#include <Pilot.h>
#define NON_INTERNATIONAL
#include <CharAttr.h>
#include "Keyboard.h"
#include <Graffiti.h>
#include <SysEvtMgr.h>
#include "MemoDB.h"
#include "MemoRsc.h"
#include "MemoMain.h"



/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define memoVersionNum					3
#define memoPrefsVersionNum			3
#define memoPrefID						0x00


#define newMemoSize  					64

#define noRecordSelected				0xffff
#define noRecordSelectedID				-1

// Update codes, used to determine how the to do list view should 
// be redrawn.
#define updateRedrawAll					0x00
#define updateCategoryChanged			0x01
#define updateDisplayOptsChanged		0x02
#define updateFontChanged				0x04


/***********************************************************************
 *
 *	Internal Structures
 *
 ***********************************************************************/

typedef struct {
	Word				topVisibleRecord;
	Word				currentRecord;
	Word				currentView;
	Word				currentCategory;
	FontID			v20editFont;
	Word				editScrollPosition;
	Boolean			showAllCategories;
	ULong				currentRecordID;
	Boolean			saveBackup;
	
	// Version 2 preferences
	FontID			v20listFont;
	
	// Version 3 preferences
	FontID			editFont;
	FontID			listFont;
} MemoPreferenceType;



/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/

static DmOpenRef		MemoDB;
static char				CategoryName [dmCategoryLength];
static Word				MemosInCategory;
static Boolean			HideSecretRecords;
static MenuBarPtr		CurrentMenu;

// The following global variable are saved to a state file.
static Word				TopVisibleRecord = 0;
static Word				CurrentRecord = noRecordSelected;
static Word				CurrentView = ListView;
static Word				CurrentCategory = dmAllCategories;
static Boolean			ShowAllCategories = true;
static FontID			ListFont = stdFont;
static FontID			EditFont = stdFont;
static Word				EditScrollPosition = 0;
static Boolean			SaveBackup = true;


/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/
static Boolean EditViewDeleteRecord (void);
static void MemoLoadPrefs(ULong*	currentRecordID);
static void MemoSavePrefs(Word scrollPosition);


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine opens the application's database, loads the 
 *               saved-state information and initializes global variables.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static Word StartApplication (void)
{
	Err err = 0;
	UInt attr;
	UInt mode;
	ULong uniqueID;
	ULong currentRecordID = 0;
	Boolean recordFound = false;
	SystemPreferencesType sysPrefs;
	UInt cardNo;
	LocalID dbID;
	Word attributes;
	
	
	// Determime if secert record should be shown.
	PrefGetPreferences (&sysPrefs);
	HideSecretRecords = sysPrefs.hideSecretRecords;

	if (HideSecretRecords)
		mode = dmModeReadWrite;
	else
		mode = dmModeReadWrite | dmModeShowSecret;


	// Find the application's data file.  If it doesn't exist, create it.
	MemoDB = DmOpenDatabaseByTypeCreator(memoDBType, sysFileCMemo, mode);
	if (! MemoDB)
		{
		err = DmCreateDatabase (0, memoDBName, sysFileCMemo, memoDBType, false);
		if (err) return err;
		
		MemoDB = DmOpenDatabaseByTypeCreator(memoDBType, sysFileCMemo, mode);
		if (! MemoDB) return (1);

		// Set the backup bit.  This is to aid syncs with non Palm software.
		DmOpenDatabaseInfo(MemoDB, &dbID, NULL, NULL, &cardNo, NULL);
		DmDatabaseInfo(cardNo, dbID, NULL, &attributes, NULL, NULL,
					NULL, NULL, NULL, NULL, NULL, NULL, NULL);
		attributes |= dmHdrAttrBackup;
		DmSetDatabaseInfo(cardNo, dbID, NULL, &attributes, NULL, NULL,
					NULL, NULL, NULL, NULL, NULL, NULL, NULL);
		
		err = MemoAppInfoInit (MemoDB);
      if (err) 
      	{
      	DmCloseDatabase(MemoDB);
      	DmDeleteDatabase(cardNo, dbID);
         return err;
         }
		}
	
	// Read the preferences.
	MemoLoadPrefs(&currentRecordID);

	// The file may have been synchronized since the last time we used it, 
	// check that the current record and the currrent category still
	// exist.  Also, if secret records are being hidden, check if the 
	// the current record is marked secret.
	CategoryGetName (MemoDB, CurrentCategory, CategoryName);
	if (*CategoryName == 0)
		{
		CurrentCategory = dmAllCategories;
		ShowAllCategories = true;
		}

	if ( DmQueryRecord (MemoDB, CurrentRecord) != 0)
		{
		DmRecordInfo (MemoDB, CurrentRecord, &attr, &uniqueID, NULL);
		recordFound = (uniqueID == currentRecordID) &&
						  ((!HideSecretRecords) || (!(attr & dmRecAttrSecret)));
		}

	if (! recordFound)
		{
		TopVisibleRecord = 0;
		CurrentRecord = noRecordSelected;
		CurrentView = ListView;
		EditScrollPosition = 0;
		}
	
	if (ShowAllCategories)
		MemosInCategory = DmNumRecordsInCategory (MemoDB, dmAllCategories);
	else
		MemosInCategory = DmNumRecordsInCategory (MemoDB, CurrentCategory);
	
	return (err);
}


/***********************************************************************
 *
 * FUNCTION:    StopApplication
 *
 * DESCRIPTION: This routine closes the application's database
 *              and saves the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void StopApplication (void)
{
	Word scrollPosition = 0;
	FormPtr frm;
	FieldPtr fld;
	

	// If we are in the "edit view", get the current scroll position.	
	if ((CurrentView == EditView) && (CurrentRecord != noRecordSelected))
		{
		frm = FrmGetFormPtr (EditView);
		fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, EditMemoField));
		scrollPosition = FldGetScrollPosition (fld);
		}

	// Close all open forms,  this will force any unsaved data to 
	// be written to the database.
	FrmCloseAllForms ();

	// Write the preferences / saved-state information.
	MemoSavePrefs(scrollPosition);
	
	// Close the application's data file.
	DmCloseDatabase (MemoDB);	
}


/***********************************************************************
 *
 * FUNCTION:    SyncNotification
 *
 * DESCRIPTION: This routine is an entry point of the memo application.
 *              It is called when the application's database is 
 *              synchronized.  This routine will resort the database.
 *
 * PARAMETERS:	 nothing
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/17/96	Initial Revision
 *
 ***********************************************************************/
static void SyncNotification (void)
{
	DmOpenRef dbP;

	// Open the application's data file.
	dbP = DmOpenDatabaseByTypeCreator(memoDBType, sysFileCMemo, dmModeReadWrite);
	if (!dbP) return;
	
	// Resort the database.
	MemoSort (dbP);
	
	DmCloseDatabase (dbP);
}


/***********************************************************************
 *
 * FUNCTION:    MemoLoadPrefs
 *
 * DESCRIPTION: Load the preferences and do any fixups needed for backwards
 *					 and forwards compatibility
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			BGT	1/13/98	Initial Revision
 *
 ***********************************************************************/
void MemoLoadPrefs(ULong*	currentRecordID)
{
	MemoPreferenceType prefs;
	Word prefsSize;
	Int prefsVersion;

	// Read the preferences / saved-state information.
	prefsSize = sizeof (MemoPreferenceType);
	prefsVersion = PrefGetAppPreferences (sysFileCMemo, memoPrefID, &prefs, &prefsSize, true);
	if (prefsVersion > memoPrefsVersionNum) {
		prefsVersion = noPreferenceFound;
	}
	if (prefsVersion > noPreferenceFound)
		{
		if (prefsVersion < 2) {
			prefs.v20listFont = ListFont;
		}
		if (prefsVersion < memoPrefsVersionNum) {
			prefs.editFont = prefs.v20editFont;
			prefs.listFont = prefs.v20listFont;
		}
		TopVisibleRecord = prefs.topVisibleRecord;
		CurrentRecord = prefs.currentRecord;
		CurrentView = prefs.currentView;
		CurrentCategory = prefs.currentCategory;
		if (prefs.editFont == largeFont)
			EditFont = largeBoldFont;
		else
			EditFont = prefs.editFont;
		EditScrollPosition = prefs.editScrollPosition;
		ShowAllCategories = prefs.showAllCategories;
		SaveBackup = prefs.saveBackup;
		*currentRecordID = prefs.currentRecordID;
		
		
		// Support transferal of preferences from the second version of the preferences.
		if (prefsVersion >= 2)
			{
			ListFont = prefs.listFont;
			}
		}
		

	// The first time this app starts register to handle vCard data.
	if (prefsVersion != memoPrefsVersionNum)
		ExgRegisterData(sysFileCMemo, exgRegExtensionID, "txt");
   
}

/***********************************************************************
 *
 * FUNCTION:    MemoSavePrefs
 *
 * DESCRIPTION: Save the preferences and do any fixups needed for backwards
 *					 and forwards compatibility
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			BGT	1/13/98	Initial Revision
 *
 ***********************************************************************/
void MemoSavePrefs(Word scrollPosition)
{
	MemoPreferenceType prefs;
	ULong uniqueID;

	// Write the preferences / saved-state information.
	prefs.topVisibleRecord = TopVisibleRecord;
	prefs.currentRecord = CurrentRecord;
	prefs.currentView = CurrentView;
	prefs.currentCategory = CurrentCategory;
	prefs.editFont = EditFont;
	prefs.showAllCategories = ShowAllCategories;
	prefs.editScrollPosition = scrollPosition;
	prefs.saveBackup = SaveBackup;
	prefs.listFont = ListFont;
	
	prefs.v20editFont = stdFont;
	prefs.v20listFont = stdFont;
		
	// Get the current record's unique id and save it with the state 
	// information.
	if ( DmQueryRecord (MemoDB, CurrentRecord) != 0)
		{
		DmRecordInfo (MemoDB, CurrentRecord, NULL, &uniqueID, NULL);
		prefs.currentRecordID = uniqueID;
		}
	else
		prefs.currentRecordID = noRecordSelectedID;

	// Write the state information.
	PrefSetAppPreferences (sysFileCMemo, memoPrefID, memoPrefsVersionNum, &prefs, 
		sizeof (MemoPreferenceType), true);

   
}

/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static VoidPtr GetObjectPtr (Word objectID)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm ();
	return (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, objectID)));

}

/***********************************************************************
 *
 * FUNCTION:    GetFocusObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to the field object, in 
 *              the current form, that has the focus.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    pointer to a field object or NULL of there is no fucus
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static FieldPtr GetFocusObjectPtr (void)
{
	FormPtr frm;
	Word focus;
	
	frm = FrmGetActiveForm ();
	focus = FrmGetFocus (frm);
	if (focus == noFocus)
		return (NULL);
		
	return (FrmGetObjectPtr (frm, focus));
}


/***********************************************************************
 *
 * FUNCTION:    SeekRecord
 *
 * DESCRIPTION: Given the index of a 'to do' record, this routine scans 
 *              forwards or backwards for displayable 'to do' records.           
 *
 * PARAMETERS:  indexP  - pointer to the index of a record to start from;
 *                        the index of the record sought is returned in
 *                        this parameter.
 *
 *              offset  - number of records to skip:   
 *                        	0 - mean seek from the current record to the
 *                             next display record, if the current record is
 *                             a displayable record, its index is retuned.
 *                         1 - mean seek foreward, skipping one displayable 
 *                             record
 *                        -1 - menas seek backwards, skipping one 
 *                             displayable record
 *                             
 *
 * RETURNED:    false is return if a displayable record was not found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/5/95	Initial Revision
 *
 ***********************************************************************/
static Boolean SeekRecord (UIntPtr indexP, Int offset, Int direction)
{
	DmSeekRecordInCategory (MemoDB, indexP, offset, direction, CurrentCategory);
	if (DmGetLastErr()) return (false);
	
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    ChangeCategory
 *
 * DESCRIPTION: This routine updates the global varibles that keep track
 *              of category information.  
 *
 * PARAMETERS:  category  - new category (index)
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static void ChangeCategory (Word category)
{
	if (ShowAllCategories)
		MemosInCategory = DmNumRecordsInCategory (MemoDB, dmAllCategories);
	else
		MemosInCategory = DmNumRecordsInCategory (MemoDB, category);
		
	CurrentCategory = category;
	TopVisibleRecord = 0;
}


/***********************************************************************
 *
 * FUNCTION:    DrawMemoTitle
 *
 * DESCRIPTION: This routine draws the title of the specified memo. 
 *
 * PARAMETERS:	 memo  - pointer to a memo
 *              x     - draw position
 *              y     - draw position
 *              width - maximum width to draw.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/18/95	Initial Revision
 *			roger	7/27/95	Combined both cases
 *
 ***********************************************************************/
static void DrawMemoTitle (CharPtr memo, short x, short y, short width)
{
	Int titleLen;
	Word charsToDraw;
	short titleWidth;
	CharPtr ptr;
	Boolean stringFit;
	

	ptr = StrChr (memo, linefeedChr);
	if (ptr)
		charsToDraw = (Word) (ptr - memo);
	else
		charsToDraw = StrLen (memo);

	titleWidth = width;
	titleLen = charsToDraw;
	FntCharsInWidth (memo, &titleWidth, &titleLen, &stringFit);

	if (stringFit)
		{
		WinDrawChars (memo, titleLen, x, y);
		}
	else
		{
		width -= (FntCharWidth ('.') * 3);
		while (titleWidth > width || 
			memo[titleLen - 1] == ' ' || 
			memo[titleLen - 1] == tabChr)
			{
			titleWidth -= FntCharWidth (memo[--titleLen]);
			}
		WinDrawChars (memo, titleLen, x, y);
		x += titleWidth;
		WinDrawChars ("...", 3, x, y);
		}
}


/***********************************************************************
 *
 * FUNCTION:    Search
 *
 * DESCRIPTION: This routine searchs the memo database for records 
 *              containing the string passed.
 *
 * PARAMETERS:	 findParams - text search parameter block
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/18/95	Initial Revision
 *			roger	7/26/95	converted to modern search mechanism
 *
 ***********************************************************************/
static void Search (FindParamsPtr findParams)
{
	Word pos;
	CharPtr header;
	UInt recordNum;
	VoidHand recordH;
	VoidHand headerH;
	RectangleType r;
	Boolean done;
	Boolean match;
	DmOpenRef dbP;
	UInt cardNo = 0;
	LocalID dbID;
	FindParamsPtr params;
	MemoDBRecordPtr memoRecP;

	params = (FindParamsPtr)findParams;
	
	// Find the application's data file.
	dbP = DmOpenDatabaseByTypeCreator(memoDBType, sysFileCMemo, params->dbAccesMode);
	if (!dbP)
		{
		findParams->more = false;
		return;
		}
	DmOpenDatabaseInfo(dbP, &dbID, 0, 0, &cardNo, 0);

	// Display the heading line.
	headerH = DmGetResource (strRsc, FindMemoHeaderStr);
	header = MemHandleLock (headerH);
	done = FindDrawHeader (findParams, header);
	MemHandleUnlock (headerH);
	if (done) goto Exit;
	

	// Search the memos for the "find" string.
	recordNum = params->recordNum;
	while (true)
		{
		// Because applications can take a long time to finish a find when
		// the result may be on the screen or for other reasons, users like
		// to be able to stop the find.  Stop the find if an event is pending.
		// This stops if the user does something with the device.  Because
		// this call slows down the search we perform it every so many 
		// records instead of every record.  The response time should still
		// be short without introducing much extra work to the search.
		
		// Note that in the implementation below, if the next 16th record is  
		// secret the check doesn't happen.  Generally this shouldn't be a 
		// problem since if most of the records are secret then the search 
		// won't take long anyways!
		if ((recordNum & 0x000f) == 0 &&			// every 16th record
			EvtSysEventAvail(true))
			{
			// Stop the search process.
			params->more = true;
			break;
			}
		
		
		recordH = DmQueryNextInCategory (dbP, &recordNum, dmAllCategories);

		// Have we run out of records?
		if (! recordH)
			{
			params->more = false;			
			break;
			}

		memoRecP = MemHandleLock (recordH);
		 
		// Search for the string passed,  if it's found display the title
		// of the memo.
		match = FindStrInStr (&(memoRecP->note), params->strToFind, &pos);
		if (match)
			{
			// Add the match to the find paramter block,  if there is no room to
			// display the match the following function will return true.
			done = FindSaveMatch (findParams, recordNum, pos, 0, 0, cardNo, dbID);

			if (! done)
				{
				// Get the bounds of the region where we will draw the results.
				FindGetLineBounds (findParams, &r);
				
				// Display the title of the description.
				DrawMemoTitle (&(memoRecP->note), r.topLeft.x+1, r.topLeft.y, 
					r.extent.x-2);
	
				params->lineNumber++;
				}
			}
		MemHandleUnlock (recordH);

		if (done) break;
		recordNum++;
		}
		
		
Exit:
	DmCloseDatabase (dbP);	
}


/***********************************************************************
 *
 * FUNCTION:    GoToItem
 *
 * DESCRIPTION: This routine is an entry point of the memo application.
 *              It is generally called as the result of hitting a 
 *              "Go to" button in the text search dialog.  The record
 *              identifies by the parameter block passed will be display,
 *              with the character range specified highlighted.
 *
 * PARAMETERS:	 goToParams   - parameter block that identifies the record to
 *                             display.
 *              launchingApp - true if the application is being launched.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/6/95	Initial Revision
 *			roger	7/26/95	converted to modern search mechanism
 *
 ***********************************************************************/
static void GoToItem (GoToParamsPtr goToParams, Boolean launchingApp)
{
	Word recordNum;
	UInt attr;
	ULong uniqueID;
	EventType event;
	
	
	recordNum = goToParams->recordNum;
	DmRecordInfo (MemoDB, recordNum, &attr, &uniqueID, NULL);

	// Make the item the first item displayed.
	TopVisibleRecord = recordNum;

	// Change the current category if necessary.
	if (CurrentCategory != dmAllCategories)
		{
		ChangeCategory (attr & dmRecAttrCategoryMask);
		}


	// If the application is already running, close all open forms.  This 
	// may cause in the database record to be reordered, so we'll find the 
	// records index by its unique id.
	if (! launchingApp)
		{
		FrmCloseAllForms ();
		DmFindRecordByID (MemoDB, uniqueID, &recordNum);
		}
		

	// Send an event to goto a form and select the matching text.
	MemSet (&event, sizeof(EventType), 0);

	event.eType = frmLoadEvent;
	event.data.frmLoad.formID = EditView;
	EvtAddEventToQueue (&event);
 
	event.eType = frmGotoEvent;
	event.data.frmGoto.recordNum = recordNum;
	event.data.frmGoto.matchPos = goToParams->matchPos;
	event.data.frmGoto.matchLen = goToParams->searchStrLen;
	event.data.frmGoto.matchFieldNum = goToParams->matchFieldNum;
	event.data.frmGoto.formID = EditView;
	EvtAddEventToQueue (&event);
	
	CurrentView = EditView;
}


/***********************************************************************
 *
 * FUNCTION:    CreateRecord
 *
 * DESCRIPTION: This routine creates a new memo record.
 *
 * PARAMETERS:  ch - first character of the new record.
 *
 * RETURNED:    true if the record was sucessfully created.
 *
 * REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			art	10/3/95		Initial Revision
 *			kcr	10/11/95		set initial graffiti upshift
 *
 ***********************************************************************/
static Boolean CreateRecord (Char ch)
{
	Ptr		p;
	Char		zero = 0;
	ULong		offset = 0;
	UInt		attr;
	UInt		index;
	VoidHand memoRec;

	// Add a new record at the end of the database.
	index = DmNumRecords (MemoDB);
	memoRec = DmNewRecord (MemoDB, &index, newMemoSize);

	// If the allocate failed, display a warning.
	if (! memoRec)
		{
		FrmAlert (DeviceFullAlert);
		return (false);
		}


	p = MemHandleLock (memoRec);
	

	// If a character was passed, write it to the new record.
	if (ch)
		{
		// Convert lower case letter to upper case.
		if (ch >= 'a' && ch <= 'z')
			ch -= 'a' - 'A';
		DmWrite (p, 0, &ch, sizeof(ch)); 
		offset += sizeof (ch);
		}


	// Null terminate the new memo string.
	DmWrite (p, offset, &zero, sizeof(Char)); 

	MemPtrUnlock (p);

	// Set the category of the new record to the current category.
	DmRecordInfo (MemoDB, index, &attr, NULL, NULL);
	attr &= ~dmRecAttrCategoryMask;
	if (CurrentCategory == dmAllCategories)
		attr |= dmUnfiledCategory;
	else
		attr |= CurrentCategory;
	DmSetRecordInfo (MemoDB, index, &attr, NULL);
	
	CurrentRecord = index;
	MemosInCategory++;

	DmReleaseRecord (MemoDB, index, true);
	

	// Move the record to its correct sort.
	if (ch)
		MemoSortRecord (MemoDB, &CurrentRecord);


	//	Set the graffiti state for an initial upshift of the 
	//	first character of a new memo.
	GrfSetState (false, false, true);

	return (true);	
}


/***********************************************************************
 *
 * FUNCTION:    DeleteRecord
 *
 * DESCRIPTION: This routine deletes the specified memo
 *
 * PARAMETERS:  index - index of record to delete
 *
 * RETURNED:    true if the record was sucessfully deleted.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/30/95	Initial Revision
 *
 ***********************************************************************/
static Boolean DeleteRecord (UInt index)
{
	Word ctlIndex;
	Word buttonHit;
	FormPtr alert;
	Boolean saveBackup;

	// Display an alert to confirm the delete operation.
	alert = FrmInitForm (DeleteMemoDialog);

	ctlIndex = FrmGetObjectIndex (alert, DeleteMemoSaveBackup);
	FrmSetControlValue (alert, ctlIndex, SaveBackup);
	buttonHit = FrmDoDialog (alert);
	saveBackup = FrmGetControlValue (alert, ctlIndex);;

	FrmDeleteForm (alert);

	if (buttonHit != DeleteMemoOk)
		return (false);

	SaveBackup = saveBackup;

	// Delete or archive the record.
	if (SaveBackup)
		DmArchiveRecord (MemoDB, index);
	else
		DmDeleteRecord (MemoDB, index);
	DmMoveRecord (MemoDB, index, DmNumRecords (MemoDB));

	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    SelectFont
 *
 * DESCRIPTION: This routine handles selection of a font in the List 
 *              View. 
 *
 * PARAMETERS:  currFontID - id of current font
 *
 * RETURNED:    id of new font
 *
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/10/97	Initial Revision
 *
 ***********************************************************************/
static FontID SelectFont (FontID currFontID)
{
	Word formID;
	FontID fontID;
	
	formID = (FrmGetFormId (FrmGetActiveForm ()));

	// Call the OS font selector to get the id of a font.
	fontID = FontSelect (currFontID);

	if (fontID != currFontID)
		FrmUpdateForm (formID, updateFontChanged);

	return (fontID);
}


/***********************************************************************
 *
 * FUNCTION:    PreferencesApply
 *
 * DESCRIPTION: This routine applies the changes made in the Preferences 
 *              Dialog
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    update code
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/18/95	Initial Revision
 *
 ***********************************************************************/
static Word PreferencesApply (void)
{
	Byte		sortOrder;
	Word		updateCode = 0;
	
	// Update the sort order.  Reset the To Do list to the top.
	sortOrder = LstGetSelection (GetObjectPtr (PreferencesSortByList));

	if (MemoGetSortOrder (MemoDB) != sortOrder)
		{
		if (sortOrder == soAlphabetic)
			{
			if (FrmAlert (alphabeticSortAlert) == alphabeticSortNo)
				return (0);
			}

		MemoChangeSortOrder (MemoDB, sortOrder);
		
		updateCode = updateDisplayOptsChanged;
		}

	return (updateCode);
}


/***********************************************************************
 *
 * FUNCTION:    PreferencesInit
 *
 * DESCRIPTION: This routine initializes the Preferences Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/18/95	Initial Revision
 *
 ***********************************************************************/
static void PreferencesInit (void)
{
	Word			sortOrder;
	CharPtr		label;
	ListPtr		lst;
	ControlPtr	ctl;
	
	
	// Set the trigger and popup list that indicates the sort order.
	sortOrder = MemoGetSortOrder (MemoDB);
	lst = GetObjectPtr (PreferencesSortByList);
	label = LstGetSelectionText (lst, sortOrder);
	ctl = GetObjectPtr (PreferencesSortByTrigger);
	CtlSetLabel (ctl, label);
	LstSetSelection (lst, sortOrder);
}


/***********************************************************************
 *
 * FUNCTION:    PreferencesHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Preferences
 *              Dialog Box" of the Memo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/18/95	Initial Revision
 *
 ***********************************************************************/
static Boolean PreferencesHandleEvent (EventPtr event)
{
	Word updateCode;
	Boolean handled = false;
	FormPtr frm;

	if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case PreferencesOkButton:
				updateCode = PreferencesApply ();
				FrmReturnToForm (ListView);
				if (updateCode)
					FrmUpdateForm (ListView, updateCode);
				handled = true;
				break;

			case PreferencesCancelButton:
				FrmReturnToForm (ListView);
				handled = true;
				break;
				
			}
		}

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		PreferencesInit ();
		FrmDrawForm (frm);
		handled = true;
		}

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    DetailsSelectCategory
 *
 * DESCRIPTION: This routine handles selection, creation and deletion of
 *              categories form the Details Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    index of the selected category.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static Word DetailsSelectCategory (WordPtr category)
{
	CharPtr name;
	Boolean categoryEdited;
	
	name = CtlGetLabel (GetObjectPtr (DetailsCategoryTrigger));

	categoryEdited = CategorySelect (MemoDB, FrmGetActiveForm (),
		DetailsCategoryTrigger, DetailsCategoryList,
		false, category, name, 1, 0);
	
	return (categoryEdited);
}



/***********************************************************************
 *
 * FUNCTION:    DetailsApply
 *
 * DESCRIPTION: This routine applies the changes made in the Details Dialog.
 *
 * PARAMETERS:  category - new catagory
 *
 * RETURNED:    code which indicates how the memo was changed,  this
 *              code is sent as the update code, in the frmUpdate event.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *			kcr	10/9/95	added 'private records' alert.
 *
 ***********************************************************************/
static Word DetailsApply (Word category, Boolean categoryEdited)
{
	UInt		attr;
	Word		updateCode = 0;
	Boolean	dirty = false;
	Boolean	secret;

	
	// Get the category and secret attribute of the current record.
	DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);

	// Get the current setting of the secret checkbox.
	secret = (CtlGetValue (GetObjectPtr (DetailsSecretCheckbox)) != 0);

	// Has the secret attribute was been changed?
	if (((attr & dmRecAttrSecret) == dmRecAttrSecret) != secret)
		{
		if (secret)
			{
			attr |= dmRecAttrSecret;
			if (!HideSecretRecords)
				FrmAlert (privateRecordInfoAlert);
			}
		else
			attr &= ~dmRecAttrSecret;
		dirty = true;
		}


	// Has the category been changed?
	if (CurrentCategory != category)
		{
		attr &= ~dmRecAttrCategoryMask;
		attr |= category;
		dirty = true;
		updateCode = updateCategoryChanged;
		}
	

	// If the current category was deleted, renamed, or merged with
	// another category, then the list view needs to be redrawn.
	if (categoryEdited)
		{
		CurrentCategory = category;
		updateCode |= updateCategoryChanged;
		}


	if (dirty)
		{
		attr |= dmRecAttrDirty;
		DmSetRecordInfo (MemoDB, CurrentRecord, &attr, NULL);
		}

	return (updateCode);
}


/***********************************************************************
 *
 * FUNCTION:    DetailsInit
 *
 * DESCRIPTION: This routine initializes the Details Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static void DetailsInit (void)
{
	UInt			attr;	
	UInt 			category;
	CharPtr		name;
	Boolean 		secret;
	ControlPtr	ctl;
			
	// Get the category and secret attribute of the current record.
	DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);
	category = attr & dmRecAttrCategoryMask;
	secret = attr & dmRecAttrSecret;


	// If the record is marked secret, turn on the secret checkbox.
	ctl = GetObjectPtr (DetailsSecretCheckbox);
	if (secret)
		CtlSetValue (ctl, true);
	else
		CtlSetValue (ctl, false);


	// Set the label of the category trigger.
	ctl = GetObjectPtr (DetailsCategoryTrigger);
	name = CtlGetLabel (ctl);
	CategoryGetName (MemoDB, category, name);
	CategorySetTriggerLabel (ctl, name);
}


/***********************************************************************
 *
 * FUNCTION:    DetailsHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Details
 *              Dialog Box".
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/

static Boolean DetailsHandleEvent (EventPtr event)
{
	static Word 		category;
	static Boolean		categoryEdited;

	Word 					updateCode;
	FormPtr 				frm;
	Boolean 				handled = false;

	if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case DetailsOkButton:
				updateCode = DetailsApply (category, categoryEdited);
				FrmReturnToForm (EditView);
				if (updateCode)
					FrmUpdateForm (EditView, updateCode);
				handled = true;
				break;

			case DetailsCancelButton:
				if (categoryEdited)
					FrmUpdateForm (EditView, updateCategoryChanged);
				FrmReturnToForm (EditView);
				handled = true;
				break;
				
			case DetailsDeleteButton:
				if ( EditViewDeleteRecord ())
					{
					frm = FrmGetActiveForm();
					FrmEraseForm (frm);
					FrmDeleteForm (frm);
					FrmCloseAllForms ();
					FrmGotoForm (ListView);
					}
				handled = true;
				break;
				

			case DetailsCategoryTrigger:
				categoryEdited = DetailsSelectCategory (&category);
				handled = true;
				break;
			}
		}

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		DetailsInit ();
		FrmDrawForm (frm);
		category = CurrentCategory;
		categoryEdited = false;
		handled = true;
		}

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewSetTitle
 *
 * DESCRIPTION: This routine formats and sets the title of the Edit View.
 *              If the Edit View is visible, the new title is drawn.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static void EditViewSetTitle (void)
{
	CharPtr titleTemplateP;
	CharPtr title;
	CharPtr ptr;
	FormPtr frm;
	char posStr [6];
	char totalStr [6];
	UInt pos;
	UInt len;
	UInt category;

	// Format as strings, the memo's postion within its category, and 
	// the total number of memos in the category.
	if (ShowAllCategories)
		category = dmAllCategories;
	else 
		category = CurrentCategory;
	pos = DmPositionInCategory (MemoDB, CurrentRecord, category);
	StrIToA (posStr, pos+1);
	StrIToA (totalStr, MemosInCategory);


	// Format the title string.  A string resource is used as a template, the
	// '#' character in the template indicates the postions of the numeric
	// values.
	titleTemplateP = MemHandleLock (DmGetResource (strRsc, EditTitleString));
	len = StrLen (posStr) + StrLen (totalStr) + StrLen (titleTemplateP);
	
	title = MemPtrNew (len);
	ErrFatalDisplayIf (!title, "Out of memory");

	ptr = StrChr (titleTemplateP, '#');
	ErrFatalDisplayIf (!ptr, "Missing '#' in MemoEdit:tStr:MemoTitleString");

	len = ptr - titleTemplateP;
	StrNCopy (title, titleTemplateP, len);
	title[len] = 0;
	StrCat (title, posStr);
	
	ptr++;
	StrCat (title, ptr);
	StrCat (title, totalStr);
	
	frm = FrmGetFormPtr (EditView);
	FrmCopyTitle (frm, title);
	MemPtrUnlock(titleTemplateP);

	MemPtrFree(title);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewSelectCategory
 *
 * DESCRIPTION: This routine  recategorizes a memo in the "Edit View".  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 *              The following global variables are modified:
 *							CurrentCategory
 *							CategoryName
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/3/95	Initial Revision
 *
 ***********************************************************************/
static void EditViewSelectCategory (void)
{
	UInt attr;
	FormPtr frm;
	Word category;
	Boolean categorySelected;
	Boolean categoryEdited;


	// Get the current category.	
	DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);
	category = attr & dmRecAttrCategoryMask;
	
	// Process the category popup list.
	frm = FrmGetActiveForm();
	categoryEdited = CategorySelect (MemoDB, frm, EditCategoryTrigger,
					  EditCategoryList, false, &category, CategoryName, 1, 0);


	categorySelected = category != (attr & dmRecAttrCategoryMask);

	// If a different category was selected,  set the category field
	// in the new record.
	if (categorySelected)
		{
		// Change the category of the record.
		DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);	
		attr &= ~dmRecAttrCategoryMask;
		attr |= category | dmRecAttrDirty;
		DmSetRecordInfo (MemoDB, CurrentRecord, &attr, NULL);
		}


	// If the current category was changed or the name of the category 
	// was edited,  draw the title.
	if (categoryEdited || categorySelected)
		{
		ChangeCategory (category);

		EditViewSetTitle ();
		}
}


/***********************************************************************
 *
 * FUNCTION:    EditViewUpdateScrollBar
 *
 * DESCRIPTION: This routine update the scroll bar.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/1/96	Initial Revision
 *
 ***********************************************************************/
static void EditViewUpdateScrollBar ()
{
	Word scrollPos;
	Word textHeight;
	Word fieldHeight;
	Short maxValue;
	FieldPtr fld;
	ScrollBarPtr bar;

	fld = GetObjectPtr (EditMemoField);
	bar = GetObjectPtr (EditMemoScrollBar);
	
	FldGetScrollValues (fld, &scrollPos, &textHeight,  &fieldHeight);

	if (textHeight > fieldHeight)
		maxValue = textHeight - fieldHeight;
	else if (scrollPos)
		maxValue = scrollPos;
	else
		maxValue = 0;

	SclSetScrollBar (bar, scrollPos, 0, maxValue, fieldHeight-1);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewLoadRecord
 *
 * DESCRIPTION: This routine loads a memo record into the Edit View form.
 *
 * PARAMETERS:  frm - pointer to the Edit View form
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void EditViewLoadRecord (FormPtr frm)
{
	UInt		attr;
	FieldPtr fld;
	ControlPtr ctl;
	VoidHand memoRec;
	
	// Get a pointer to the memo field.
	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, EditMemoField));
	
	// Get the current record.
	memoRec = DmGetRecord (MemoDB, CurrentRecord);
	ErrFatalDisplayIf ((! memoRec), "Bad record");

	// Set the font used by the memo field.
	FldSetFont (fld, EditFont);
	
	FldSetTextHandle (fld, memoRec);
	FldSetScrollPosition (fld, EditScrollPosition);
	
	// Set the global variable that keeps track of the current category
	// to the category of the current record.
	DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);
	CurrentCategory = attr & dmRecAttrCategoryMask;
	
	// Set the view's title
	EditViewSetTitle ();

	// Set the label that contains the note's category.
	ctl = GetObjectPtr (EditCategoryTrigger);
	CategoryGetName (MemoDB, CurrentCategory, CategoryName);
	CategorySetTriggerLabel (ctl, CategoryName);

	EditViewUpdateScrollBar ();
}


/***********************************************************************
 *
 * FUNCTION:    EditViewSaveRecord
 *
 * DESCRIPTION: This routine save a memo record to the memo database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *			kcr	11/16/95	use DmReleaseRecord to set dirty attribute
 *
 ***********************************************************************/
static void EditViewSaveRecord (void)
{
	UInt		attr;
	CharPtr  ptr;
	Boolean 	empty;
	Boolean	dirty;
	FieldPtr fld;

	
	// Find out if the field has been modified or if it's empty.
	fld = GetObjectPtr (EditMemoField);
	ptr = FldGetTextPtr (fld);
	dirty = FldDirty (fld);
	empty = (*ptr == 0);

	FldReleaseFocus (fld);

	// Release any free space in the memo field.
	FldCompactText (fld);

	// Clear the handle value in the field, otherwise the handle
	// will be free when the form is disposed of.
	FldSetTextHandle (fld, 0);
	
	// If there's data in an existing record, mark it dirty if 
	// necessary and release it.
	if (! empty)
		{
		DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);

		if (HideSecretRecords && (attr & dmRecAttrSecret))
			MemosInCategory--;			

		DmReleaseRecord (MemoDB, CurrentRecord, dirty);
		
		// Move the current record to the correct sort position.
		if (dirty)
			MemoSortRecord (MemoDB, &CurrentRecord);
		}

	// If the record is empty, delete it.
	else
		{
		if (dirty)
			{
			DmDeleteRecord (MemoDB, CurrentRecord);
			DmMoveRecord (MemoDB, CurrentRecord, DmNumRecords (MemoDB));
			}
		else
			DmRemoveRecord (MemoDB, CurrentRecord);

		CurrentRecord = noRecordSelected;
		MemosInCategory--;
		}
}


/***********************************************************************
 *
 * FUNCTION:    EditViewChangeFont
 *
 * DESCRIPTION: This routine redisplay the memo in the font specified.
 *              It is called when one of the font push-buttons is presed.
 *
 * PARAMETERS:  controlID - id to button pressed.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *			kcr	10/20/95		handles two-button font change mechanism
 *
 ***********************************************************************/
static void EditViewChangeFont (void)
{
	FontID	fontID;
	FieldPtr fld;
	
	// Call the OS font selector to get the id of a font.
	fontID = FontSelect (EditFont);

	if (fontID != EditFont)
		{
		EditFont = fontID;
		
		// FldSetFont will redraw the field if it is visible.
		fld = GetObjectPtr (EditMemoField);
		FldSetFont (fld, fontID);
		}

	EditViewUpdateScrollBar ();
}



/***********************************************************************
 *
 * FUNCTION:    EditViewDeleteRecord
 *
 * DESCRIPTION: This routine deletes a memo record..
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static Boolean EditViewDeleteRecord (void)
{
	FormPtr  frm;
	FieldPtr fld;
	CharPtr  ptr;
	Word ctlIndex;
	Word buttonHit;
	FormPtr alert;
	Boolean empty;
	Boolean saveBackup;


	frm = FrmGetFormPtr (EditView);
	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, EditMemoField));

	// Find out if the field is empty.
	ptr = FldGetTextPtr (fld);
	empty = (*ptr == 0);

	// Display an alert to confirm the operation.
	if (!empty)
		{
		alert = FrmInitForm (DeleteMemoDialog);
	
		ctlIndex = FrmGetObjectIndex (alert, DeleteMemoSaveBackup);
		FrmSetControlValue (alert, ctlIndex, SaveBackup);
		buttonHit = FrmDoDialog (alert);
		saveBackup = FrmGetControlValue (alert, ctlIndex);;
	
		FrmDeleteForm (alert);
	
		if (buttonHit == DeleteMemoCancel)
			return (false);
	
		SaveBackup = saveBackup;
		}

	// Clear the handle value in the field, otherwise the handle
	// will be free when the form is disposed of.
	FldSetTextHandle (fld, 0);

	// Delete or archive the record.
	if (empty && (! FldDirty (fld)))
		{
		DmRemoveRecord (MemoDB, CurrentRecord);
		}
	else
		{
		if (SaveBackup)
			DmArchiveRecord (MemoDB, CurrentRecord);
		else
			DmDeleteRecord (MemoDB, CurrentRecord);
		DmMoveRecord (MemoDB, CurrentRecord, DmNumRecords (MemoDB));
		}

	MemosInCategory--;
	CurrentRecord = noRecordSelected;

	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/29/95	Initial Revision
 *			kcr	11/7/95	converted to common about box
 *
 ***********************************************************************/
static Boolean EditViewDoCommand (Word command)
{
	FieldPtr fld;
	FormPtr frm;
	Boolean handled = true;

	switch (command)
		{
		case NewMemoCmd:
			EditViewSaveRecord ();
			CreateRecord (0);
			EditScrollPosition = 0;
			if (CurrentRecord != noRecordSelected)
				{
				EditViewLoadRecord (FrmGetActiveForm ());
				fld = GetFocusObjectPtr ();
				if (fld) FldGrabFocus (fld);
				}
			else
				FrmGotoForm (ListView);
			break;
		
		case DeleteMemoCmd:
			if (EditViewDeleteRecord ())
				FrmGotoForm (ListView);
			break;
			
		case SendMemoCmd:
			fld = GetObjectPtr (EditMemoField);
			if (FldGetTextLength(fld) > 0)
				{
				EditViewSaveRecord();
				MemoSendRecord(MemoDB, CurrentRecord);
				
				// Redisplay the record.  If the IR loopback mechanism sends the 
				// record to this app the goto action code closes all forms and 
				// send a frmGotoEvent.  Load the record again only if the form 
				// still exits.
				frm = FrmGetActiveForm ();
				if (frm)
					EditViewLoadRecord (frm);
				}
			else
				FrmAlert(NoDataToBeamAlert);
			break;
		/*
		case SendCategoryCmd:
			fld = GetObjectPtr (EditMemoField);
			if (FldGetTextLength(fld) > 0)
				{
				FldCompactText (fld);
				MemoSendCategory(MemoDB, CurrentCategory);
				}
			else
				FrmAlert(NoDataToBeamAlert);
			break;
		*/
		
		case EditOptionsFontsCmd:
			EditViewChangeFont ();
			break; 

		case EditOptionsTopOfPageCmd:
			fld = GetObjectPtr (EditMemoField);
			if (! fld) break;
			FldSetScrollPosition (fld, 0);
			EditViewUpdateScrollBar ();
			break;

		case EditOptionsBottomOfPageCmd:
			fld = GetObjectPtr (EditMemoField);
			if (! fld) break;
			FldSetScrollPosition (fld, FldGetTextLength (fld));
			EditViewUpdateScrollBar ();
			break;

		case EditOptionPhoneLookupCmd:
			fld = GetObjectPtr (EditMemoField);
			if (! fld) break;
			PhoneNumberLookup (fld);
			break;
			
		case EditOptionsAboutCmd:
			AbtShowAbout (sysFileCMemo);
			break;
			
		default:
			handled = false;
		}	

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewScroll
 *
 * DESCRIPTION: This routine scrolls the memo edit view a page or a 
 *              line at a time.  For page scrolling, when the 
 *              top of a memo is visible, scrolling up will 
 *              display the display the botton of the previous memo.
 *              If the bottom of a memo is visible, scrolling down will
 *              display the top of the next memo.
 *
 * PARAMETERS:  direction - up or dowm
 *              oneLine   - true if scrolling a single line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/1/96	Initial Revision
 *
 ***********************************************************************/
static void EditViewScroll (Short linesToScroll)
{
	Word				blankLines;
	Short				min;
	Short				max;
	Short				value;
	Short				pageSize;
	FieldPtr			fld;
	ScrollBarPtr	bar;
	
	fld = GetObjectPtr (EditMemoField);

	if (linesToScroll < 0)
		{
		blankLines = FldGetNumberOfBlankLines (fld);
		FldScrollField (fld, -linesToScroll, up);
		
		// If there were blank lines visible at the end of the field
		// then we need to update the scroll bar.
		if (blankLines)
			{
			// Update the scroll bar.
			bar = GetObjectPtr (EditMemoScrollBar);
			SclGetScrollBar (bar, &value, &min, &max, &pageSize);
			if (blankLines > -linesToScroll)
				max += linesToScroll;
			else
				max -= blankLines;
			SclSetScrollBar (bar, value, min, max, pageSize);
			}
		}

	else if (linesToScroll > 0)
		FldScrollField (fld, linesToScroll, down);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewPageScroll
 *
 * DESCRIPTION: This routine scrolls the message a page up or down.
 *
 * PARAMETERS:   direction     up or down
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/1/96	Initial Revision
 *
 ***********************************************************************/
static void EditViewPageScroll (DirectionType direction)
{
	Int seekDirection;
	Word category;
	UInt recordNum;
	Short value;
	Short min;
	Short max;
	ULong uniqueID;
	Short pageSize;
	Word linesToScroll;
	FieldPtr fld;
	ScrollBarPtr bar;

	fld = GetObjectPtr (EditMemoField);
	
	if (FldScrollable (fld, direction))
		{
		linesToScroll = FldGetVisibleLines (fld) - 1;
		FldScrollField (fld, linesToScroll, direction);

		// Update the scroll bar.
		bar = GetObjectPtr (EditMemoScrollBar);
		SclGetScrollBar (bar, &value, &min, &max, &pageSize);

		if (direction == up)
			value -= linesToScroll;
		else
			value += linesToScroll;
		
		SclSetScrollBar (bar, value, min, max, pageSize);
		return;
		}


	// Move to the next or previous memo.
	if (direction == up)
		{
		seekDirection = dmSeekBackward;
		EditScrollPosition = maxFieldTextLen;		
		}
	else
		{
		seekDirection = dmSeekForward;
		EditScrollPosition = 0;
		}

	if (ShowAllCategories)
		category = dmAllCategories;
	else
		category = CurrentCategory;

	recordNum = CurrentRecord;
	DmSeekRecordInCategory (MemoDB, &recordNum, 1, seekDirection, category);
	if (recordNum == CurrentRecord) return;

	SndPlaySystemSound (sndInfo);

	// Saving the current record may cause it to move if the records are 
	// sorted alphabeticly.
	DmRecordInfo (MemoDB, recordNum, NULL, &uniqueID, NULL);
	EditViewSaveRecord ();
	DmFindRecordByID (MemoDB, uniqueID, &CurrentRecord);

	EditViewLoadRecord (FrmGetActiveForm ());
	FldGrabFocus (fld);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewExit
 *
 * DESCRIPTION: This routine is call when the Edit View is exited.  It
 *              releases any memory allocated for the Edit View.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/17/95		Initial Revision
 *
 ***********************************************************************/
static void EditViewExit (void)
{
	FormPtr  frm;
	CharPtr title;

	// Free the title string.
	frm = FrmGetActiveForm ();
	title = FrmGetTitle (frm);
	if (title)
		{
		MemPtrFree (title);
		title = NULL;
		}
}


/***********************************************************************
 *
 * FUNCTION:    EditViewInit
 *
 * DESCRIPTION: This routine initials the Edit View form.
 *
 * PARAMETERS:  frm - pointer to the Edit View form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/31/95	Initial Revision
 *			art	7/1/96	Set field hasScrollBar attribute
 *
 ***********************************************************************/
static void EditViewInit (FormPtr frm)
{
	FieldPtr 		fld;
	FieldAttrType	attr;
	

	// Have the field send event to maintain the scroll bar.
	fld = GetObjectPtr (EditMemoField);
	FldGetAttributes (fld, &attr);
	attr.hasScrollBar = true;
	FldSetAttributes (fld, &attr);

	EditViewLoadRecord (frm);

	CurrentView = EditView;
}


/***********************************************************************
 *
 * FUNCTION:    EditViewUpdateDisplay
 *
 * DESCRIPTION: This routine update the display of the edit view
 *
 * PARAMETERS:  updateCode - a code that indicated what changes have been
 *                           made to the view.
 *                		
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/3/95	Initial Revision
 *
 ***********************************************************************/
static Boolean EditViewUpdateDisplay (Word updateCode)
{
	UInt attr;
	Word category;
	FormPtr frm;

	frm = FrmGetActiveForm ();

	if (updateCode == updateCategoryChanged)
		{
		DmRecordInfo (MemoDB, CurrentRecord, &attr, NULL, NULL);
		category = attr & dmRecAttrCategoryMask;
		ChangeCategory (category);

		// If we are editing a secret record and secret records are hidden
		// then increment the record count so that the correct record count
		// is shown.
		if (HideSecretRecords && (attr & dmRecAttrSecret))
			MemosInCategory++;			

		// Set the title of the edit view.
		EditViewSetTitle ();
	
		// Set the label of the category trigger.
		CategoryGetName (MemoDB, CurrentCategory, CategoryName);
		CategorySetTriggerLabel (GetObjectPtr (EditCategoryTrigger),
			CategoryName);
		return (true);
		}
		
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    EditViewHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Edit View"
 *              of the Memo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static Boolean EditViewHandleEvent (EventPtr event)
{
	FormPtr frm;
	Boolean handled = false;
	FieldPtr fldP;


	if (event->eType == keyDownEvent)
		{
		if (ChrIsHardKey(event->data.keyDown.chr))
			{
			EditViewSaveRecord ();
			FrmGotoForm (ListView);
			handled = true;
			}

		else if (event->data.keyDown.chr == pageUpChr)
			{
			EditViewPageScroll (up);
			handled = true;
			}

		else if (event->data.keyDown.chr == pageDownChr)
			{
			EditViewPageScroll (down);
			handled = true;
			}
		
		// Send data key presed?
		else if (event->data.keyDown.chr == sendDataChr)
			{
			if (FldGetTextLength(GetObjectPtr (EditMemoField)) > 0)
				{
				EditViewSaveRecord();
				MemoSendRecord(MemoDB, CurrentRecord);
				
				// Redisplay the record.  If the IR loopback mechanism sends the 
				// record to this app the goto action code closes all forms and 
				// send a frmGotoEvent.  Load the record again only if the form 
				// still exits.
				frm = FrmGetActiveForm ();
				if (frm)
					EditViewLoadRecord (frm);
				}
			else
				FrmAlert(NoDataToBeamAlert);
			handled = true;
			}
		}


	else if (event->eType == ctlSelectEvent)
		{		
		switch (event->data.ctlSelect.controlID)
			{
			case EditCategoryTrigger:
				EditViewSelectCategory ();
				handled = true;
				break;

			case EditDoneButton:
				EditViewSaveRecord ();
				FrmGotoForm (ListView);
				handled = true;
				break;

			case EditDetailsButton:
				FrmPopupForm (DetailsDialog);
				handled = true;
				break;
			}
		}


	else if (event->eType == menuEvent)
		{
		handled = EditViewDoCommand (event->data.menu.itemID);
		}
		

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		EditViewInit (frm);
		FrmDrawForm (frm);
		FrmSetFocus (frm, FrmGetObjectIndex (frm, EditMemoField));
		handled = true;
		}
		

	else if (event->eType == frmGotoEvent)
		{
		frm = FrmGetActiveForm ();
		CurrentRecord = event->data.frmGoto.recordNum;
		EditViewInit (frm);
		fldP = GetObjectPtr (EditMemoField);
		FldSetScrollPosition(fldP, event->data.frmGoto.matchPos);
		FldSetSelection(fldP, event->data.frmGoto.matchPos, 
			event->data.frmGoto.matchPos + event->data.frmGoto.matchLen);
		EditViewUpdateScrollBar ();
		FrmDrawForm (frm);
		FrmSetFocus (frm, FrmGetObjectIndex (frm, EditMemoField));
		handled = true;
		}


	else if (event->eType == frmUpdateEvent)
		{
		handled =  EditViewUpdateDisplay (event->data.frmUpdate.updateCode);
		}

	else if (event->eType == fldChangedEvent)
		{
		frm = FrmGetActiveForm ();
		EditViewUpdateScrollBar ();
		handled = true;
		}
		

	else if (event->eType == frmSaveEvent || 
				event->eType == frmCloseEvent)
		{
		if ( FldGetTextHandle (GetObjectPtr (EditMemoField)))
			EditViewSaveRecord ();
		}


	else if (event->eType == sclRepeatEvent)
		{
		EditViewScroll (event->data.sclRepeat.newValue - 
			event->data.sclRepeat.value);
		}

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/29/95		Initial Revision
 *			kcr	11/7/95		converted to common about box
 *
 ***********************************************************************/
static void ListViewDoCommand (Word command)
{

	switch (command)
		{
		case ListOptionsFontsCmd:
			ListFont = SelectFont (ListFont);
			break;
			
		case ListOptionsPreferencesCmd:
			FrmPopupForm (PreferencesDialog);
			break;

		case ListRecordSendCategoryCmd:
			MemoSendCategory(MemoDB, CurrentCategory);
			break;

		case ListOptionsAboutCmd:
			MenuEraseStatus (CurrentMenu);
			AbtShowAbout (sysFileCMemo);
			break;
		}	
}


/***********************************************************************
 *
 * FUNCTION:    ListViewNumberOfRows
 *
 * DESCRIPTION: This routine return the maximun number of visible rows,
 *              with the current list view font setting.
 *
 * PARAMETERS:  table - List View table
 *
 * RETURNED:    maximun number of displayable rows
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/28/97	Initial Revision
 *
 ***********************************************************************/
static Word ListViewNumberOfRows (TablePtr table)
{
	Word				rows;
	Word				rowsInTable;
	Word				tableHeight;
	FontID			currFont;
	RectangleType	r;


	rowsInTable = TblGetNumberOfRows (table);

	TblGetBounds (table, &r);
	tableHeight = r.extent.y;

	currFont = FntSetFont (ListFont);
	rows = tableHeight / FntLineHeight ();
	FntSetFont (currFont);

	if (rows <= rowsInTable)
		return (rows);
	else
		return (rowsInTable);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDrawRecord
 *
 * DESCRIPTION: This routine draws the title memo record in the list 
 *              view.  This routine is called by the table routine, 
 *              TblDrawTable, each time a line of the table needs to
 *              be drawn.
 *
 * PARAMETERS:  table  - pointer to the memo list table (TablePtr)
 *              row    - row of the table to draw
 *              column - column of the table to draw 
 *              bounds - bound to the draw region
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewDrawRecord (VoidPtr table, Word row, Word column, 
	RectanglePtr bounds)
{
	Word len;
	Word category;
	Word recordNum;
	Handle memoH;
	short x, y;
	CharPtr memoP;
	Word pos;
	char posStr [6];
	
	// Get the record number that corresponds to the table item to draw.
	// The record number is stored in the "intValue" field of the item.
	recordNum = TblGetRowID (table, row);

	memoH = DmQueryRecord(MemoDB, recordNum);
	memoP = MemHandleLock(memoH);

	x = bounds->topLeft.x + 1;
	y = bounds->topLeft.y;

	FntSetFont (ListFont);
	
	// Format the memo's postion, within its category, an draw it.
	if (ShowAllCategories)
		category = dmAllCategories;
	else 
		category = CurrentCategory;
	pos = DmPositionInCategory (MemoDB, recordNum, category);
	StrIToA (posStr, pos+1);
	len = StrLen(posStr);
	posStr[len++] = '.';
	posStr[len] = 0;
	
	if (len < 3) x += FntCharWidth ('1');
	WinDrawChars (posStr, len, x, y);
	x += FntCharsWidth (posStr, len) + 4;


	// Display the memo's title, the title is the first line of the memo.
	DrawMemoTitle (memoP, x, y, bounds->extent.x - x);
	MemHandleUnlock(memoH);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewUpdateScrollers
 *
 * DESCRIPTION: This routine draws or erases the list view scroll arrow
 *              buttons.
 *
 * PARAMETERS:  frm          -  pointer to the to do list form
 *              bottomRecord -  record index of the last visible record
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewUpdateScrollers (FormPtr frm, Word bottomRecord)
{
	Word pos;
	Word rows;
	Word maxValue;

	rows = ListViewNumberOfRows (GetObjectPtr(ListTable));
	if (MemosInCategory > rows)
		{
		pos = DmPositionInCategory (MemoDB, TopVisibleRecord, CurrentCategory);
		maxValue = MemosInCategory - rows;
		}
	else
		{
		pos = 0;
		maxValue = 0;
		}

	SclSetScrollBar (GetObjectPtr (ListScrollBar), pos, 0, maxValue, rows);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewLoadTable
 *
 * DESCRIPTION: This routine loads memo database records into
 *              the list view form.
 *
 * PARAMETERS:  recordNum index of the first record to display.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewLoadTable (FormPtr frm)
{
	Word			row;
	Word			recordNum;
	Word			lineHeight;
	Word			dataHeight;
	Word			tableHeight;
	Word			lastRecordNum;
	Word			numRows;
	ULong			uniqueID;
	FontID		currFont;
	TablePtr 	table;
	VoidHand		recordH;
	RectangleType r;

	
	table = GetObjectPtr (ListTable);

	TblGetBounds (table, &r);
	tableHeight = r.extent.y;

	currFont = FntSetFont (ListFont);
	lineHeight = FntLineHeight ();
	FntSetFont (currFont);

	dataHeight = 0;
	
	recordNum = TopVisibleRecord;

	// For each row in the table, store the record number in the table item
	// that will dispaly the record.  
	numRows = TblGetNumberOfRows (table);
	for (row = 0; row < numRows; row++)
		{
		// Get the next record in the currunt category.
		recordH = DmQueryNextInCategory (MemoDB, &recordNum, CurrentCategory);
		
		// If the record was found, store the record number in the table item,
		// otherwise set the table row unusable.
		if (recordH && (tableHeight >= dataHeight + lineHeight))
			{
			TblSetRowID (table, row, recordNum);
			TblSetItemStyle (table, row, 0, customTableItem);
			TblSetItemFont (table, row, 0, ListFont);
			TblSetRowHeight (table, row, lineHeight);

			DmRecordInfo (MemoDB, recordNum, NULL, &uniqueID, NULL);
			if ((TblGetRowData (table, row) != uniqueID) ||
				 ( ! TblRowUsable (table, row)))
				{
				TblSetRowUsable (table, row, true);

				// Store the unique id of the record in the row.
				TblSetRowData (table, row, uniqueID);

				// Mark the row invalid so that it will draw when we call the 
				// draw routine.
				TblMarkRowInvalid (table, row);
				}

			lastRecordNum = recordNum;
			if (row+1 < numRows) recordNum++;
			
			dataHeight += lineHeight;
			}
		else
			{
			TblSetRowUsable (table, row, false);
			}
		}
		

	// Update the scroll arrows.
	ListViewUpdateScrollers (frm, lastRecordNum);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewLoadRecords
 *
 * DESCRIPTION: This routine loads memo database records into
 *              the list view form.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewLoadRecords (FormPtr frm)
{
	TablePtr 	table;
	Word			recordNum;
	Word			rowsInTable;
	
	if (ShowAllCategories)
		CurrentCategory = dmAllCategories;

	table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ListTable));
	rowsInTable = ListViewNumberOfRows (table);

	// Is the current record before the first visible record?
	if (CurrentRecord != noRecordSelected)
		{
		if (TopVisibleRecord > CurrentRecord)
			TopVisibleRecord = CurrentRecord;
		
		// Is the current record after the last visible record?
		else
			{
			recordNum = TopVisibleRecord;
			DmSeekRecordInCategory (MemoDB, &recordNum, rowsInTable-1,
				dmSeekForward, CurrentCategory);
			if (recordNum < CurrentRecord)
				TopVisibleRecord = CurrentRecord;
			}
		}

	
	// Make sure we show a full display of records.
	if (MemosInCategory)
		{
		recordNum = dmMaxRecordIndex;
		DmSeekRecordInCategory (MemoDB, &recordNum, (rowsInTable-1),
			dmSeekBackward, CurrentCategory);
		TopVisibleRecord = min (TopVisibleRecord, recordNum);
		}
	else
		TopVisibleRecord = 0;

	ListViewLoadTable (frm);

	// Set the callback routine that will draw the records.
	TblSetCustomDrawProcedure (table, 0, ListViewDrawRecord);

	TblSetColumnUsable (table, 0, true);	
}


/***********************************************************************
 *
 * FUNCTION:    ListViewSelectCategory
 *
 * DESCRIPTION: This routine handles selection, creation and deletion of
 *              categories form the Details Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    The index of the new category.
 *
 *              The following global variables are modified:
 *							CurrentCategory
 *							ShowAllCategories
 *							CategoryName
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static Word ListViewSelectCategory (void)
{
	FormPtr frm;
	TablePtr table;
	Word category;
	Boolean categoryEdited;

	
	// Process the category popup list.  
	category = CurrentCategory;

	frm = FrmGetActiveForm();
	categoryEdited = CategorySelect (MemoDB, frm, ListCategoryTrigger,
					  ListCategoryList, true, &category, CategoryName, 1, 0);
	
	if (category == dmAllCategories)
		ShowAllCategories = true;
	else
		ShowAllCategories = false;
		
	if (categoryEdited || (category != CurrentCategory))
		{
		ChangeCategory (category);

		// Display the new category.
		ListViewLoadRecords (frm);
		table = GetObjectPtr (ListTable);
		TblEraseTable (table);
		TblDrawTable (table);
		}

	return (category);
}

/***********************************************************************
 *
 * FUNCTION:    ListViewNextCategory
 *
 * DESCRIPTION: This routine display the next category,  if the last
 *              catagory isn't being displayed  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 *              The following global variables are modified:
 *							CurrentCategory
 *							ShowAllCategories
 *							CategoryName
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/15/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewNextCategory (void)
{
	Word category;
	FormPtr frm;
	TablePtr table;
	ControlPtr ctl;

	category = CategoryGetNext (MemoDB, CurrentCategory);

	if (category != CurrentCategory)
		{
		if (category == dmAllCategories)
			ShowAllCategories = true;
		else
			ShowAllCategories = false;

		ChangeCategory (category);

		// Set the label of the category trigger.
		ctl = GetObjectPtr (ListCategoryTrigger);
		CategoryGetName (MemoDB, CurrentCategory, CategoryName);
		CategorySetTriggerLabel (ctl, CategoryName);


		// Display the new category.
		TopVisibleRecord = 0;
		frm = FrmGetActiveForm ();
		ListViewLoadTable (frm);
		table = GetObjectPtr (ListTable);
		TblEraseTable (table);
		TblDrawTable (table);
		}
}


/***********************************************************************
 *
 * FUNCTION:    ListViewPageScroll
 *
 * DESCRIPTION: This routine scrolls the list of of memo titles
 *              in the direction specified.
 *
 * PARAMETERS:  direction - up or dowm
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *			roger 7/27/95	Copied fixed code from Address Book
 *
 ***********************************************************************/
static void ListViewPageScroll (DirectionType direction)
{
	TablePtr table;
	Word rowsInTable;
	UInt newTopVisibleRecord;

	table = GetObjectPtr (ListTable);
	rowsInTable = ListViewNumberOfRows (table);

	newTopVisibleRecord = TopVisibleRecord;
	CurrentRecord = noRecordSelected;

	// Scroll the table down a page (less one row).
	if (direction == down)
		{
		// Try going forward one page
		if (!SeekRecord (&newTopVisibleRecord, rowsInTable - 1, dmSeekForward))
			{
			// Try going backwards one page from the last record
			newTopVisibleRecord = dmMaxRecordIndex;
			if (!SeekRecord (&newTopVisibleRecord, rowsInTable - 1, dmSeekBackward))
				{
				// Not enough records to fill one page.  Start with the first record
				newTopVisibleRecord = 0;
				SeekRecord (&newTopVisibleRecord, 0, dmSeekForward);
				}
			}
		}
		
	// Scroll up a page (less one row).
	else
		{
		if (!SeekRecord (&newTopVisibleRecord, rowsInTable - 1, dmSeekBackward))
			{
			// Not enough records to fill one page.  Start with the first record
			newTopVisibleRecord = 0;
			SeekRecord (&newTopVisibleRecord, 0, dmSeekForward);
			}
		}
	


	// Avoid redraw if no change
	if (TopVisibleRecord != newTopVisibleRecord)
		{
		TopVisibleRecord = newTopVisibleRecord;
		ListViewLoadRecords (FrmGetActiveForm ());
		TblRedrawTable(table);
		}
}



/***********************************************************************
 *
 * FUNCTION:    ListViewScroll
 *
 * DESCRIPTION: This routine scrolls the list of of memo titles
 *              in the direction specified.
 *
 * PARAMETERS:  direction - up or dowm
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *			roger 7/27/95	Copied fixed code from Address Book
 *
 ***********************************************************************/
static void ListViewScroll (Short linesToScroll)
{
	Int 				i;
	Word				rows;
	Word				lastRow;
	Word 				scrollAmount;
	UInt 				newTopVisibleRecord;
	TablePtr 		table;
	RectangleType	scrollR;
	RectangleType	vacated;
	DirectionType	direction;


	table = GetObjectPtr (ListTable);
	CurrentRecord = noRecordSelected;


	// Find the new top visible record
	newTopVisibleRecord = TopVisibleRecord;

	// Scroll down.
	if (linesToScroll > 0)
		SeekRecord (&newTopVisibleRecord, linesToScroll, dmSeekForward);

	// Scroll up.
	else if (linesToScroll < 0)
		SeekRecord (&newTopVisibleRecord, -linesToScroll, dmSeekBackward);

	ErrFatalDisplayIf (TopVisibleRecord == newTopVisibleRecord, 
		"Invalid scroll value");

	TopVisibleRecord = newTopVisibleRecord;


	// Move the bits that will remain visible.
	rows = ListViewNumberOfRows (table);
	if (((linesToScroll > 0) && (linesToScroll < rows)) ||
		 ((linesToScroll < 0) && (-linesToScroll < rows)))
		{
		scrollAmount = 0;
	
		if (linesToScroll > 0)
			{
			lastRow = TblGetLastUsableRow (table) - 1;
			for (i = 0; i < linesToScroll; i++)
				{
				scrollAmount += TblGetRowHeight (table, lastRow);
				TblRemoveRow (table, 0);
				}
			direction = up;
			}
		else
			{
			for (i = 0; i < -linesToScroll; i++)
				{
				scrollAmount += TblGetRowHeight (table, 0);
				TblInsertRow (table, 0);
				}
			direction = down;
			}

		TblGetBounds (table, &scrollR);
		WinScrollRectangle (&scrollR, direction, scrollAmount, &vacated);
		WinEraseRectangle (&vacated, 0);
		}
	

	ListViewLoadTable (FrmGetActiveForm ());
	TblRedrawTable(table);
}



/***********************************************************************
 *
 * FUNCTION:    ListViewInit
 *
 * DESCRIPTION: This routine initializes the "List View" of the 
 *              Memo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewInit (FormPtr frm)
{
	ControlPtr ctl;
	
	ListViewLoadRecords (frm);

	// Set the label of the category trigger.
	ctl = GetObjectPtr (ListCategoryTrigger);
	CategoryGetName (MemoDB, CurrentCategory, CategoryName);
	CategorySetTriggerLabel (ctl, CategoryName);

	CurrentView = ListView;
}


/***********************************************************************
 *
 * FUNCTION:    ListViewInvertMoveIndicator
 *
 * DESCRIPTION:   If draw is true, then save the area behind the rectangle,
 *					then draw the indicator there. If draw is false, then restore 
 *					the screen bits.
 *              
 *
 * PARAMETERS:	 itemR - bounds of the move indicator
 *					 savedBits - if draw is true, then restore this window of bits at 
 *					 	itemR.
 *					 draw - draw or erase the move indicator. 
 *
 * RETURNED:	 WinHandle - handle to a saved window of screen bits, if the move
 *				indicator is visible. Otherwise, the value is 0.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/29/96	Initial Revision
 *
 ***********************************************************************/
static WinHandle ListViewInvertMoveIndicator (RectanglePtr itemR, WinHandle savedBits, 
	Boolean draw)
{
	UInt i;
	Word err;
	WinHandle winH = 0;
	RectangleType indictatorR;
	CustomPatternType pattern;
	CustomPatternType savedPattern;


	indictatorR.topLeft.x = itemR->topLeft.x;
	indictatorR.topLeft.y = itemR->topLeft.y + itemR->extent.y - 2;
	indictatorR.extent.x = itemR->extent.x;
	indictatorR.extent.y = 2;
				
	if (draw)
		{
		WinGetPattern (savedPattern);
	
		for (i = 0; i < sizeof (CustomPatternType) / sizeof (*pattern); i++)
			pattern[i]= 0xAA55;
	
		WinSetPattern (pattern);
	
		winH = WinSaveBits (&indictatorR, &err);
	
		WinFillRectangle (&indictatorR, 0);
	
		WinSetPattern (savedPattern);
		}
		
	else
		{
		WinRestoreBits (savedBits, indictatorR.topLeft.x, indictatorR.topLeft.y);
		}
	
	return (winH);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewSelectMemo
 *
 * DESCRIPTION: This routine selects (highlights) the item specified,  
 *              
 *
 * PARAMETERS:	 
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/29/96	Initial Revision
 *
 ***********************************************************************/
static void ListViewSelectMemo (EventPtr event)
{
	Int sortOrder;
	Short row;
	Word selectedRow;
	Word column;
	Word recordNum;
	Word selectedRecord;
	Short x, y;
	Boolean penDown = true;
	Boolean moving = false;
	Boolean selected = true;
	TablePtr table;
	WinHandle savedBits;
	RectangleType r;
	
	sortOrder = MemoGetSortOrder (MemoDB);

	row = event->data.tblSelect.row;
	column = event->data.tblSelect.column;
	table = event->data.tblSelect.pTable;

	// Highlight the item the pen when down on.
	selectedRecord = TblGetRowID (table, row);
	TblGetItemBounds (table, row, column, &r);
	WinInvertRectangle (&r, 0);


	// Trace the pen until it move enough to constitute a move operation or until 
	// the pen it released.
	while (true) 
		{
		PenGetPoint (&x, &y, &penDown);
		if (! penDown) break;
		
		if (! moving)
			{
			if (sortOrder != soAlphabetic)
				{
				// Is the pen still within the bounds of the item it went down on, 
				// if not draw the move indicator.
				if (! RctPtInRectangle (x, y, &r))
					{
					moving = true;
					
					TblGetItemBounds (table, row, column, &r);
					savedBits = ListViewInvertMoveIndicator (&r, 0, true);
					}
				}
			else
				selected = RctPtInRectangle (x, y, &r);
			}

		else if (! RctPtInRectangle (x, y, &r))
			{
			// Above the first item ?
			if (row < 0)
				{
				if (y >= r.topLeft.y)
					{
					row++;
					ListViewInvertMoveIndicator (&r, savedBits, false);
					r.topLeft.y -= r.extent.y;
					savedBits = ListViewInvertMoveIndicator (&r, 0, true);
					}					
				}

			// Move up.
			else if (y < r.topLeft.y)
				{
				recordNum = TblGetRowID (table, row);
				if (SeekRecord (&recordNum, 1, dmSeekBackward))
					{
					ListViewInvertMoveIndicator (&r, savedBits, false);
					if (row)
						row--;
					else
						{
						ListViewScroll (-1);
						if (TblFindRowID (table, selectedRecord, &selectedRow))
							{
							TblGetItemBounds (table, selectedRow, column, &r);
							WinInvertRectangle (&r, 0);
							}
						}
					TblGetItemBounds (table, row, column, &r);
					savedBits = ListViewInvertMoveIndicator (&r, 0, true);
					}
				else if (row == 0)
					{
					row--;
					ListViewInvertMoveIndicator (&r, savedBits, false);
					r.topLeft.y -= r.extent.y;
					savedBits = ListViewInvertMoveIndicator (&r, 0, true);
					}
				}

			// Move down
			else 
				{
				recordNum = TblGetRowID (table, row);
				if (SeekRecord (&recordNum, 1, dmSeekForward))
					{
					ListViewInvertMoveIndicator (&r, savedBits, false);
					if (row < TblGetLastUsableRow (table))
						row++;
					else
						{
						ListViewScroll (1);
						if (TblFindRowID (table, selectedRecord, &selectedRow))
							{
							TblGetItemBounds (table, selectedRow, column, &r);
							WinInvertRectangle (&r, 0);
							}
						}
					TblGetItemBounds (table, row, column, &r);
					savedBits = ListViewInvertMoveIndicator (&r, 0, true);
					}
				}
			}
		}
		

	// Turn off the move indicator, if it is on.
	if (moving)
		{
		savedBits = ListViewInvertMoveIndicator (&r, savedBits, false);
		}
	
	// If the highlighted item is visible, unhighlight it.
	if (TblFindRowID (table, selectedRecord, &selectedRow))
		{
		TblGetItemBounds (table, selectedRow, column, &r);
		WinInvertRectangle (&r, 0);
		}

	if (moving)
		{
		if (row >= 0)
			{
			recordNum = TblGetRowID (table, row);
			if (selectedRecord == recordNum)
				return;
			
			recordNum++;
			}
		else
			{
			recordNum = TblGetRowID (table, 0);;
			}

		DmMoveRecord (MemoDB, selectedRecord, recordNum);
		
		if (selectedRecord < TopVisibleRecord)
			TopVisibleRecord--;
		ListViewLoadTable (FrmGetActiveForm());
		TblRedrawTable (table);
		}
		
	// If we didn't move the item then it's been selected for editing, go to the
	// edit view.
	else if (sortOrder != soAlphabetic || selected)

		{
		CurrentRecord = TblGetRowID (event->data.tblSelect.pTable, 
			event->data.tblSelect.row);
		EditScrollPosition = 0;
		FrmGotoForm (EditView);
		}
}

/***********************************************************************
 *
 * FUNCTION:    ListViewUpdateDisplay
 *
 * DESCRIPTION: This routine update the display of the list view
 *
 * PARAMETERS:  updateCode - a code that indicated what changes have been
 *                           made to the view.
 *                		
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/19/95	Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewUpdateDisplay (Word updateCode)
{
	TablePtr table;

	if (updateCode & (updateDisplayOptsChanged | updateFontChanged))
		{
		if (updateCode & updateDisplayOptsChanged)
			TopVisibleRecord = 0;

		ListViewLoadRecords (FrmGetActiveForm());
		table = GetObjectPtr (ListTable);
		TblEraseTable (table);
		TblDrawTable (table);		

		return (true);
		}
		
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "List View"
 *              of the Memo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewHandleEvent (EventPtr event)
{
	FormPtr frm;
	Boolean handled = false;

	if (event->eType == keyDownEvent)
		{
		// Memo button pressed?
		if (ChrIsHardKey(event->data.keyDown.chr))
			{
			if (!(event->data.keyDown.modifiers & poweredOnKeyMask))
				ListViewNextCategory ();
			handled = true;
			}

		// Scroll up key presed?
		else if (event->data.keyDown.chr == pageUpChr)
			{
			ListViewPageScroll (up);
			handled = true;
			}

		// Scroll down key presed?
		else if (event->data.keyDown.chr == pageDownChr)
			{
			ListViewPageScroll (down);
			handled = true;
			}
			
		// If printable character, create a new record.
		else if (IsPrint (GetCharAttr(), event->data.keyDown.chr))
			{
			if (CreateRecord (event->data.keyDown.chr))
				{
				FrmGotoForm (EditView);

//				chr = event->data.keyDown.chr;
//				if (chr >= 'a' && chr <= 'z')
//				event->data.keyDown.chr -= 'a' - 'A';
//				EvtAddEventToQueue (event);
				}

			handled = true;
			}			
		}

		
	else if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case ListNewButton:
				if (CreateRecord (0))
					FrmGotoForm (EditView);
				handled = true;
				break;
				
			case ListCategoryTrigger:
				ListViewSelectCategory ();
				handled = true;
				break;
			}
		}


	else if (event->eType == tblEnterEvent)
		{
		ListViewSelectMemo (event);
		handled = true;
		}


	else if (event->eType == tblSelectEvent)
		{
		// An item in the list of memos was selected, display it.
		CurrentRecord = TblGetRowID (event->data.tblSelect.pTable, 
			event->data.tblSelect.row);
		EditScrollPosition = 0;
		FrmGotoForm (EditView);
		handled = true;
		}
		
		
	else if (event->eType == menuEvent)
		{
		ListViewDoCommand (event->data.menu.itemID);
		return (true);
		}

		
	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		ListViewInit (frm);
		FrmDrawForm (frm);
		handled = true;
		}
	
	else if (event->eType == frmUpdateEvent)
		{
		handled =  ListViewUpdateDisplay (event->data.frmUpdate.updateCode);
		}

	else if (event->eType == sclRepeatEvent)
		{
		ListViewScroll (event->data.sclRepeat.newValue - 
			event->data.sclRepeat.value);
		}

	return (handled);
}



/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and sets the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95		Initial Revision
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent (EventPtr event)
{
	Word formID;
	FormPtr frm;

	if (event->eType == frmLoadEvent)
		{
		// Load the form resource.
		formID = event->data.frmLoad.formID;
		frm = FrmInitForm (formID);
		FrmSetActiveForm (frm);		
		
		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time it receives an
		// event.
		switch (formID)
			{
			case ListView:
				FrmSetEventHandler (frm, ListViewHandleEvent);
				break;
	
			case EditView:
				FrmSetEventHandler (frm, EditViewHandleEvent);
				break;
	
			case DetailsDialog:
				FrmSetEventHandler (frm, DetailsHandleEvent);
				break;

			case PreferencesDialog:
				FrmSetEventHandler (frm, PreferencesHandleEvent);
				break;
				
			}
		return (true);
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    EventLoop
 *
 * DESCRIPTION: This routine is the event loop for the Memo
 *              aplication.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static void EventLoop (void)
{
	Word error;
	EventType event;

	do
		{
		EvtGetEvent (&event, evtWaitForever);
		
		if (! SysHandleEvent (&event))
		
			if (! MenuHandleEvent (CurrentMenu, &event, &error))
			
				if (! ApplicationHandleEvent (&event))
	
					FrmDispatchEvent (&event); 

		}
	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the Memo
 *              application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *			art	1/3098	Removed sysAppLaunchCmdSaveData logic
 *
 ***********************************************************************/
DWord	PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
	Word error;

	if (cmd == sysAppLaunchCmdNormalLaunch)
		{
		error = StartApplication ();
		if (error)
			return (error);

		FrmGotoForm (CurrentView);
		EventLoop ();
		StopApplication ();
		}
		
	else if (cmd == sysAppLaunchCmdFind)
		{
		Search ((FindParamsPtr)cmdPBP);
		}
	
	
	// This action code might be sent to the app when it's already running
	//  if the use hits the Find soft key next to the Graffiti area.
	else if (cmd == sysAppLaunchCmdGoTo)
		{
		if (launchFlags & sysAppLaunchFlagNewGlobals) 
			{
			error = StartApplication ();
			if (error) return (error);

			GoToItem ((GoToParamsPtr) cmdPBP, true);
			
			EventLoop ();
			StopApplication ();	
			}
		else
			GoToItem ((GoToParamsPtr) cmdPBP, false);
		}


	// Launch code sent to running app before sysAppLaunchCmdFind
	// or other action codes that will cause data searches or manipulation.												//  data searches or manipulation.
//	else if (cmd == sysAppLaunchCmdSaveData)
//		{
//		FrmSaveAllForms ();
//		}
	

	// This action code is sent after the system is reset. We use this time
	//  to create our default database if this is a hard reset
	else if (cmd == sysAppLaunchCmdSystemReset) {
		if (((SysAppLaunchCmdSystemResetType*)cmdPBP)->createDefaultDB) {
			Handle	resH;
			resH = DmGet1Resource(sysResTDefaultDB, sysResIDDefaultDB);
			if (resH) {
				DmCreateDatabaseFromImage(MemHandleLock(resH));
				MemHandleUnlock(resH);
				DmReleaseResource(resH);
				}
			// register to receive txt files on hard reset
			ExgRegisterData(sysFileCMemo, exgRegExtensionID, "txt");
			}
		}
	

	else if (cmd == sysAppLaunchCmdSyncNotify)
		{
		SyncNotification ();
		}
	

      // Present the user with ui to perform a lookup and return a string
      // with information from the selected record.
	else if (cmd == sysAppLaunchCmdExgReceiveData)
   	{
       DmOpenRef dbP;
       
      // if our app is not active, we need to open the database 
      // the subcall flag is used here since this call can be made without launching the app
      if (!(launchFlags & sysAppLaunchFlagSubCall))
      	{
      	dbP = DmOpenDatabaseByTypeCreator (memoDBType, sysFileCMemo, dmModeReadWrite);
      	}
      else
      	{
      	dbP = MemoDB;

			// Save any data the we may be editing.
			FrmSaveAllForms ();
      	}
      
      if (dbP != NULL)
      	{
			error = MemoReceiveData(dbP, (ExgSocketPtr) cmdPBP);
			
				
         if (!(launchFlags & sysAppLaunchFlagSubCall))
				error = DmCloseDatabase(dbP);
			}

		}
      
      
	// This action code is sent by the DesktopLink server when it create 
	// a new database.  We will initializes the new database.
	else if (cmd == sysAppLaunchCmdInitDatabase)
		{
		MemoAppInfoInit (((SysAppLaunchCmdInitDatabaseType*)cmdPBP)->dbP);
		}


	return (0);
}

