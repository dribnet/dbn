/*******************************************************************
 *                       
 *  Copyright (c) 1994-1999 3Com Corporation or its subsidiaries.
 *  All rights reserved.
 *
 *
 *-------------------------------------------------------------------
 * FileName:
 *      MemoTransfer.c
 *
 * Description:
 *      Memo Book routines to transfer records.
 *
 * History:
 *      9/17/97  roger - Created
 *
 *******************************************************************/


// Set this to get to private database defines
#define __ADDRMGR_PRIVATE__

#include <Pilot.h>
#define NON_INTERNATIONAL
#include <CharAttr.h>
#include <Hardware.h>		// hwrDisplayWidth

#include "MemoDB.h"
#include "MemoMain.h"
#include "MemoRsc.h"


#define identifierLengthMax		40
#define mimeVersionString			"MIME-Version: 1.0\015\012"
#define mimeMultipartString 		"Content-type: multipart/mixed;"
#define mimeBoundaryString 		"boundary="
#define memoFilenameExtension			".txt"
#define simpleBoundary				"simple boundary"
#define delimiter						"--" simpleBoundary
#define crlf							"\015\012"

#define importBufferMaxLength		 80

/***********************************************************************
 *
 * FUNCTION:    GetChar
 *
 * DESCRIPTION: Function to get a character from the exg transport. 
 *
 * PARAMETERS:  exgSocketP - the exg connection
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   8/15/97   Initial Revision
 *
 ***********************************************************************/
static Word GetChar(const void * exgSocketP)
{
	ULong len;
	Byte c;
	Err err;
	
	len = ExgReceive((ExgSocketPtr) exgSocketP, &c, sizeof(c), &err);
	
	if (err || len == 0)
		return EOF;
	else
		return c;
}


/***********************************************************************
 *
 * FUNCTION:    PutString
 *
 * DESCRIPTION: Function to put a string to the exg transport. 
 *
 * PARAMETERS:  exgSocketP - the exg connection
 *					 stringP - the string to put
 *
 * RETURNED:    nothing
 *					 If the all the string isn't sent an error is thrown using ErrThrow.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   8/15/97   Initial Revision
 *
 ***********************************************************************/
static void PutString(const void * exgSocketP, const Char * const stringP)
{
	ULong len;
	Err err;
	
	len = ExgSend((ExgSocketPtr) exgSocketP, stringP, StrLen(stringP), &err);
	
	// If the bytes were not sent throw an error.
	if (len == 0 && StrLen(stringP) > 0)
		ErrThrow(err);
}


/***********************************************************************
 *
 * FUNCTION:    SetDescriptionAndFilename
 *
 * DESCRIPTION: Derive and allocate a decription and filename from some text. 
 *
 * PARAMETERS:  textP - the text string to derive the names from
 *					 descriptionPP - pointer to set to the allocated description 
 *					 descriptionHP - Handle to set to the allocated description 
 *					 filenamePP - pointer to set to the allocated filename 
 *					 filenameHP - Handle to set to the allocated description 
 *
 * RETURNED:    a description and filename are allocated and the pointers are set
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   11/4/97   Initial Revision
 *
 ***********************************************************************/
static void SetDescriptionAndFilename(CharPtr textP, CharPtr *descriptionPP, 
	Handle *descriptionHP, CharPtr *filenamePP, Handle *filenameHP)
{
	CharPtr descriptionP;
   Int descriptionSize;
	SWord descriptionWidth;
	Boolean descriptionFit;
	CharPtr spaceP;
	CharPtr filenameP;
	Byte filenameLength;
	
	
	descriptionSize = StrLen(textP);
	descriptionWidth = hwrDisplayWidth;
	FntCharsInWidth (textP, &descriptionWidth, &descriptionSize, &descriptionFit);
	
	if (descriptionSize > 0)
		{
		*descriptionHP = MemHandleNew(descriptionSize+sizeofchar('\0'));
		if (*descriptionHP)
			{
			descriptionP = MemHandleLock(*descriptionHP);
			MemMove(descriptionP, textP, descriptionSize);
			descriptionP[descriptionSize] = nullChr;
			}
		}
	else
		{
		*descriptionHP = DmGetResource(strRsc, BeamDescriptionStr);
		descriptionP = MemHandleLock(*descriptionHP);
		}
	
		
	if (descriptionSize > 0)
		{
		// Now form a file name.  Use only the first word or two.
		spaceP = StrChr(descriptionP, spaceChr);
		if (spaceP)
			// Check for a second space
			spaceP = StrChr(spaceP + sizeofchar(spaceChr), spaceChr);
		
		// If at least two spaces were found then use only that much of the description.
		// If less than two spaces were found then use all of the description.
		if (spaceP)
			filenameLength = spaceP - descriptionP;
		else
			filenameLength = StrLen(descriptionP);
		
		
		// Allocate space and form the filename
		*filenameHP = MemHandleNew(filenameLength + StrLen(memoFilenameExtension) + sizeofchar('\0'));
		filenameP = MemHandleLock(*filenameHP);
		if (filenameP)
			{
			MemMove(filenameP, descriptionP, filenameLength);
			MemMove(&filenameP[filenameLength], memoFilenameExtension, 
				StrLen(memoFilenameExtension) + sizeofchar('\0'));
			}
		}
	else
		{
		*filenameHP = DmGetResource(strRsc, BeamFilenameStr);
		filenameP = MemHandleLock(*filenameHP);
		}
	
	
	*descriptionPP = descriptionP;
	*filenamePP = filenameP;
}


/***********************************************************************
 *
 * FUNCTION:    MemoSendRecordTryCatch
 *
 * DESCRIPTION: Send a record.  
 *
 * PARAMETERS:	 dbP - pointer to the database to add the record to
 * 				 recordNum - the record number to send
 * 				 recordP - pointer to the record to send
 * 				 exgSocketP - the exchange socket used to send
 *
 * RETURNED:    0 if there's no error
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger  12/11/97  Initial Revision
 *
 ***********************************************************************/
static Err MemoSendRecordTryCatch (DmOpenRef dbP, Int recordNum, 
	MemoDBRecordPtr recordP, ExgSocketPtr exgSocketP)
{
   volatile Err error = 0;
	
	
		// An error can happen anywhere during the send process.  It's easier just to 
		// catch the error.  If an error happens, we must pass it into ExgDisconnect.
		// It will then cancel the send and display appropriate ui.
		ErrTry
			{
			MemoExportMime(dbP, recordNum, recordP, exgSocketP, PutString, true, false);
			}
		
		ErrCatch(inErr)
			{
			error = inErr;
			} ErrEndCatch

	
	return error;
}


/***********************************************************************
 *
 * FUNCTION:    MemoSendRecord
 *
 * DESCRIPTION: Send a record.  
 *
 * PARAMETERS:		dbP - pointer to the database to add the record to
 * 					recordNum - the record to send
 *
 * RETURNED:    true if the record is found and sent
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   5/9/97   Initial Revision
 *
 ***********************************************************************/
extern void MemoSendRecord (DmOpenRef dbP, Int recordNum)
{
   MemoDBRecordPtr recordP;
   Handle recordH;
   Handle descriptionH;
   Err error;
	ExgSocketType exgSocket;
	Handle nameH;
	
	
	// important to init structure to zeros...
	MemSet(&exgSocket, sizeof(exgSocket), 0);
	
	// Form a description of what's being sent.  This will be displayed
	// by the system send dialog on the sending and receiving devices.
   recordH = DmQueryRecord (dbP, recordNum);
   recordP = (MemoDBRecordType *) MemHandleLock(recordH);
   
   // Set the description to be the beginning of the memo
	descriptionH = NULL;
	exgSocket.description = NULL;
	
	// Set the exg description to the record's description.
	SetDescriptionAndFilename(&recordP->note, &exgSocket.description, 
		&descriptionH, &exgSocket.name, &nameH);
	
	
	exgSocket.length = MemHandleSize(recordH);		// rough guess
	exgSocket.target = sysFileCMemo;
	error = ExgPut(&exgSocket);   // put data to destination
	if (!error)
		{
		error = MemoSendRecordTryCatch(dbP, recordNum, recordP, &exgSocket);

		ExgDisconnect(&exgSocket, error);
		}
	
	
	// Clean up
	if (descriptionH)
		{
		MemHandleUnlock (descriptionH);
		if (MemHandleDataStorage (descriptionH))
			DmReleaseResource(descriptionH);
		else
			MemHandleFree(descriptionH);
		}
	if (nameH)
		{
		MemHandleUnlock (nameH);
		if (MemHandleDataStorage (nameH))
			DmReleaseResource(nameH);
		else
			MemHandleFree(nameH);
		}
	MemHandleUnlock(recordH);
	
	
	return;
}


/***********************************************************************
 *
 * FUNCTION:    MemoSendCategoryTryCatch
 *
 * DESCRIPTION: Send all visible records in a category.  
 *
 * PARAMETERS:		dbP - pointer to the database to add the record to
 * 					categoryNum - the category of records to send
 * 					exgSocketP - the exchange socket used to send
 * 					index - the record number of the first record in the category to send
 *
 * RETURNED:    0 if there's no error
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger  12/11/97  Initial Revision
 *
 ***********************************************************************/
static Err MemoSendCategoryTryCatch (DmOpenRef dbP, Word categoryNum, 
	ExgSocketPtr exgSocketP, Word index)
{
	volatile Err error = 0;
	volatile Handle outRecordH = 0;
   MemoDBRecordType *outRecordP;
	
	
	// An error can happen anywhere during the send process.  It's easier just to 
	// catch the error.  If an error happens, we must pass it into ExgDisconnect.
	// It will then cancel the send and display appropriate ui.
	ErrTry
		{

		// Write out the beginning of a multipart mime message
		PutString(exgSocketP, 
			mimeVersionString
			"Content-type: multipart/mixed; boundary=\"" simpleBoundary "\"" crlf crlf);
      
		// Loop through all records in the category.
		while (DmSeekRecordInCategory(dbP, &index, 0, dmSeekForward, categoryNum) == 0)
			{
			// Emit the record.  If the record is private do not emit it.
			outRecordH = DmQueryRecord (dbP, index);
			
			if (outRecordH != 0)
				{
				outRecordP = (MemoDBRecordType *) MemHandleLock(outRecordH);
				
				// Emit a mime boundary
				PutString(exgSocketP, delimiter crlf);
				
				MemoExportMime(dbP, index, outRecordP, exgSocketP, PutString, true, true);
				
				MemHandleUnlock(outRecordH);
				}
			
			index++;
			}
		outRecordH = 0;
		dbP = 0;
		
		// All done.  Write out an epilogue.
		PutString(exgSocketP, delimiter "--" crlf crlf);
		}
	
	ErrCatch(inErr)
		{
		error = inErr;
		
		if (outRecordH)
			MemHandleUnlock(outRecordH);
		} ErrEndCatch
	
	return error;	
}

/***********************************************************************
 *
 * FUNCTION:    MemoSendCategory
 *
 * DESCRIPTION: Send all visible records in a category.  
 *
 * PARAMETERS:		 dbP - pointer to the database to add the record to
 * 					 categoryNum - the category of records to send
 *
 * RETURNED:    true if any records are found and sent
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   5/9/97   Initial Revision
 *
 ***********************************************************************/
extern void MemoSendCategory (DmOpenRef dbP, Word categoryNum)
{
	Err error;
   Char description[dmCategoryLength];
	Word index;
	Boolean foundAtLeastOneRecord;
	ExgSocketType exgSocket;
	UInt mode;
	LocalID dbID;
	UInt cardNo;
	Boolean databaseReopened;
	
	
	// If the database was opened to show secret records, reopen it to not see 
	// secret records.  The idea is that secret records are not sent when a 
	// category is sent.  They must be explicitly sent one by one.
	DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
	if (mode & dmModeShowSecret)
		{
		dbP = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
		databaseReopened = true;
		}
	else
		databaseReopened = false;
	
	
	// important to init structure to zeros...
	MemSet(&exgSocket, sizeof(exgSocket), 0);
	
	
	// Make sure there is at least one record in the category.
	index = 0;
	foundAtLeastOneRecord = false;
	while (true)
		{
		if (DmSeekRecordInCategory(dbP, &index, 0, dmSeekForward, categoryNum) != 0)
			break;
		
		foundAtLeastOneRecord = DmQueryRecord(dbP, index) != 0;
		if (foundAtLeastOneRecord)
			break;
		
		
		index++;
		}
	
	
	// We should send the category because there's at least one record to send.
	if (foundAtLeastOneRecord)
		{
		// Form a description of what's being sent.  This will be displayed
		// by the system send dialog on the sending and receiving devices.
		CategoryGetName (dbP, categoryNum, description);
		exgSocket.description = description;
		
		// Now form a file name
		exgSocket.name = MemPtrNew(StrLen(description) + StrLen(memoFilenameExtension) + sizeofchar('\0'));
		if (exgSocket.name)
			{
			StrCopy(exgSocket.name, description);
			StrCat(exgSocket.name, memoFilenameExtension);
			}
		
		exgSocket.length = 0;		// rough guess
		exgSocket.target = sysFileCMemo;
		error = ExgPut(&exgSocket);   // put data to destination
		
		if (!error)
			{
			error = MemoSendCategoryTryCatch (dbP, categoryNum, &exgSocket, index);
			
			ExgDisconnect(&exgSocket, error);
			}
		
		// Clean up
		if (exgSocket.name)
			MemPtrFree(exgSocket.name);
		}
	else
		FrmAlert(NoDataToBeamAlert);

	if (databaseReopened)
		DmCloseDatabase(dbP);
	
	return;
}


/***********************************************************************
 *
 * FUNCTION:		ReceiveData
 *
 * DESCRIPTION:		Receives data into the output field using the Exg API
 *
 * PARAMETERS:		exgSocketP, socket from the app code
 *						 sysAppLaunchCmdExgReceiveData
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
extern Err MemoReceiveData(DmOpenRef dbP, ExgSocketPtr exgSocketP)
{
	volatile Err err;	
	
	// accept will open a progress dialog and wait for your receive commands
	err = ExgAccept(exgSocketP);
	
	if (!err)
		{
		// Catch errors receiving records.  The import routine will clean up the
		// incomplete record.  This routine displays an error message.
		ErrTry
			{
			// Keep importing records until it can't
			while (MemoImportMime(dbP, exgSocketP, GetChar, false, false))
				{};
			}
		
		ErrCatch(inErr)
			{
			err = inErr;
			} ErrEndCatch
		
		ExgDisconnect(exgSocketP, err); // closes transfer dialog
		}
	
	
	return err;
}


/***********************************************************************
 *
 * FUNCTION:		MemoSetGoToParams
 *
 * DESCRIPTION:	Store the information necessary to navigate to the 
 *                record inserted into the launch code's parameter block.
 *
 * PARAMETERS:		 dbP        - pointer to the database to add the record to
 *						 exgSocketP - parameter block passed with the launch code
 *						 uniqueID   - unique id of the record inserted
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/17/97	Created
 *
 ***********************************************************************/
static void MemoSetGoToParams (DmOpenRef dbP, ExgSocketPtr exgSocketP, DWord uniqueID)
{
	Word		recordNum;
	UInt		cardNo;
	LocalID 	dbID;

	
	if (! uniqueID) return;

	DmOpenDatabaseInfo (dbP, &dbID, NULL, NULL, &cardNo, NULL);

	// The this the the first record inserted, save the information
	// necessary to navigate to the record.
	if (! exgSocketP->goToParams.uniqueID)
		{
		DmFindRecordByID (dbP, uniqueID, &recordNum);

		exgSocketP->goToCreator = sysFileCMemo;
		exgSocketP->goToParams.uniqueID = uniqueID;
		exgSocketP->goToParams.dbID = dbID;
		exgSocketP->goToParams.dbCardNo = cardNo;
		exgSocketP->goToParams.recordNum = recordNum;
		}

	// If we already have a record then make sure the record index 
	// is still correct.  Don't update the index if the record is not
	// in your the app's database.
	else if (dbID == exgSocketP->goToParams.dbID &&
			   cardNo == exgSocketP->goToParams.dbCardNo)
		{
		DmFindRecordByID (dbP, exgSocketP->goToParams.uniqueID, &recordNum);

		exgSocketP->goToParams.recordNum = recordNum;
		}
}


/************************************************************
 *
 * FUNCTION: ReadThroughCRLF
 *
 * DESCRIPTION: Consume data up to and including the next CRLF.
 *
 * PARAMETERS: 
 *			inputStreamP	- pointer to where to import from
 *			bufferP - where the input stream is stored
 *			bufferLengthP - the length of bufferP used
 *
 * RETURNED: error code or zero for no error.
 *
 * ASSUMPTIONS:
 *			Buffer is full when called
 *  		Buffer is big enough to hold a full line (including LF)
 *			  ...so CR/LF will never split
 *	END CONDITION:
 *			Buffer is full when routine exits.
 *
 *
 *	REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			bob	1/26/98  initial revision
 *
 *************************************************************/
static Err ReadThroughCRLF(ExgSocketPtr inputStreamP, CharPtr bufferP, WordPtr bufferLengthP)
{
	char *c;
	Word charsRead;
	Err err = 0;
	Boolean gotOne = false;
	
	while (*bufferLengthP > 0 && !gotOne)
	{
		c = StrChr(bufferP, crChr);
		if (c == NULL)
			c = &bufferP[*bufferLengthP];		// end of the buffer
		else if (c < bufferP + *bufferLengthP - 1)		// guard against buffer splitting cr/lf
		{
			c += sizeofchar(crChr) + sizeofchar(linefeedChr);
			gotOne = true;
		}
		
		// Consume everything up to the CR/NULL
		MemMove(bufferP, c, &bufferP[*bufferLengthP] - c);
		*bufferLengthP = &bufferP[*bufferLengthP] - c;

		// Read in more chars
		charsRead = ExgReceive(inputStreamP, bufferP + *bufferLengthP, importBufferMaxLength - *bufferLengthP, &err);
		*bufferLengthP += charsRead;
		bufferP[*bufferLengthP] = nullChr;
		if (err) break;
	}
	
	return err;
}


/************************************************************
 *
 * FUNCTION: MemoImportFinishRecord
 *
 * DESCRIPTION: Make sure record is null terminated, and close it.
 *
 * PARAMETERS: 
 *			dbP - pointer to the database to add the record to
 *			indexNew	- index of new record
 *			newRecordH - handle to new record
 *			newRecordSize - bytes currently in new record
 *
 *	REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			bob	1998-02-05	Moved out of MemoImportMime
 *
 *************************************************************/
static void MemoImportFinishRecord(DmOpenRef dbP, UInt indexNew, Handle *newRecordHPtr, Word *newRecordSizePtr, VoidPtr inputStream)
{
	CharPtr newRecordP;
	Handle newHandle;						// Used to follow resized records which move
	DWord uniqueID;


	ErrNonFatalDisplayIf(*newRecordHPtr == NULL, "Null record handle.");
	
	// Make sure the record is nullChr terminated
	newRecordP = MemHandleLock(*newRecordHPtr);
	if (newRecordP[*newRecordSizePtr - sizeof(char)] != nullChr)
	{
		MemHandleUnlock(*newRecordHPtr);
		newHandle = DmResizeRecord(dbP, indexNew, *newRecordSizePtr + sizeofchar(nullChr));
		if (newHandle)
			*newRecordHPtr = newHandle;
		else
			ErrThrow(true);
		
		newRecordP = MemHandleLock(*newRecordHPtr);
		DmWrite(newRecordP, *newRecordSizePtr, "", sizeofchar(nullChr));
	}

	// let the record go
	MemHandleUnlock(*newRecordHPtr);
	DmReleaseRecord(dbP, indexNew, true);
	
	// BUG 10009 record not in sorted order
	MemoSortRecord (dbP, &indexNew);

	// Store the information necessary to navigate to the record inserted.
	DmRecordInfo(dbP, indexNew, NULL, &uniqueID, NULL);
	MemoSetGoToParams (dbP, inputStream, uniqueID);
	
	*newRecordHPtr = NULL;
	*newRecordSizePtr = 0;
}


/************************************************************
 *
 * FUNCTION: MemoImportMime
 *
 * DESCRIPTION: Import a Mime record.
 *
 * PARAMETERS: 
 *			dbP - pointer to the database to add the record to
 *			inputStream	- pointer to where to import the record from
 *			inputFunc - function to get input from the stream
 *			obeyUniqueIDs - true to obey any unique ids if possible
 *			beginAlreadyRead - whether the begin statement has been read
 *
 * RETURNS: true if the input was read
 *
 *	REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			rsf	4/24/97		Initial Revision
 *			bob	1998-01-26	re-wrote MIME parser part to get delimiters right
 *
 *************************************************************/
extern Boolean 
MemoImportMime(DmOpenRef dbR, VoidPtr inputStream, GetCharF inputFunc, 
	Boolean obeyUniqueIDs, Boolean beginAlreadyRead)
{
	char *c;
	char boundaryString[69+2] = "";
	Handle newRecordH = NULL;
	CharPtr newRecordP;
	Handle newHandle;						// Used to follow resized records which move
	volatile UInt indexNew = dmMaxRecordIndex;
	volatile DmOpenRef dbP = dbR;
	WordPtr charAttrP;
	volatile Err err = 0;
	Char buffer[importBufferMaxLength + 1];
	Word bufferLength = 0;
	Word charsRead;
	Word charsToWrite;
	Word newRecordSize = 0;
	CharPtr nextCrChr;
	int addCr;
	CharPtr boundaryP;
	CharPtr boundaryEndP;
	
	
	charAttrP = GetCharAttr();
	// Keep the buffer always null terminated so we can use string functions on it.
	buffer[importBufferMaxLength] = nullChr;
	
	// An error happens usually due to no memory.  It's easier just to 
	// catch the error.  If an error happens, we remove the last record.  
	// Then we throw a second time so the caller receives it and displays a message.
	ErrTry
	{
		// Read chars into the buffer
		charsRead = ExgReceive((ExgSocketPtr) inputStream, buffer, importBufferMaxLength - bufferLength, (Err*)&err);
		if (err) ErrThrow(false);
		bufferLength += charsRead;
		buffer[bufferLength] = nullChr;
		
		if (charsRead == 0)
			return false;
		
		// MIME start, find MIME ID and version
		if (StrNCompare(buffer, mimeVersionString, StrLen(mimeVersionString)) == 0)
		{
			// Remove the MIME header
			MemMove(buffer, &buffer[StrLen(mimeVersionString)], bufferLength - StrLen(mimeVersionString));
			bufferLength -= StrLen(mimeVersionString);
			
			// Read chars into the buffer
			charsRead = ExgReceive((ExgSocketPtr) inputStream, &buffer[bufferLength], importBufferMaxLength - bufferLength, (Err*)&err);
			if (err) ErrThrow(false);
			bufferLength += charsRead;
			buffer[bufferLength] = nullChr;
			
			// scan header for a multi-part identifier
			// skip anything else until we get an entirely blank line
			do {
				if (StrNCompare(buffer, mimeMultipartString, StrLen(mimeMultipartString)) == 0)
				{
				// found a multi-part header, parse out the boundary string
					boundaryP = StrStr(buffer, mimeBoundaryString);
					boundaryP += StrLen(mimeBoundaryString);
					
					// Remove the boundary stuff so we can read in more into the buffer
					MemMove(buffer, boundaryP, &buffer[bufferLength] - boundaryP);
					bufferLength = (&buffer[bufferLength] - boundaryP);
					
					// Read chars into the buffer
					charsRead = ExgReceive((ExgSocketPtr) inputStream, &buffer[bufferLength], importBufferMaxLength - bufferLength, (Err*)&err);
					if (err) ErrThrow(false);
					bufferLength += charsRead;
					buffer[bufferLength] = nullChr;
					
					boundaryP = buffer;
					if (*boundaryP == '"')
						{
						boundaryP++;
						boundaryEndP = StrChr(boundaryP, '"');
						}
					else
						{
						boundaryEndP = StrChr(boundaryP, crChr);
						}
					if (boundaryEndP == NULL)
					{
						err = exgErrBadData;
						ErrThrow(false);
					}
					boundaryString[0] = '-';
					boundaryString[1] = '-';
					MemMove(&boundaryString[2], boundaryP, boundaryEndP - boundaryP);
					boundaryString[boundaryEndP - boundaryP + 2] = nullChr;
					
					c = StrChr(boundaryEndP, crChr);
					if (c == NULL)
					{
						err = exgErrBadData;
						ErrThrow(false);
					}
					c += sizeofchar(crChr) + sizeofchar(linefeedChr);
					
					// Remove the boundary stuff so we can read in more into the buffer
					MemMove(buffer, c, &buffer[bufferLength] - c);
					bufferLength = (&buffer[bufferLength] - c);
				}
				else
				{
					// just an ordinary header line, skip it
					err = ReadThroughCRLF(inputStream, buffer, &bufferLength);
					if (err) ErrThrow(false);
				}
				
				// Read chars into the buffer
				charsRead = ExgReceive((ExgSocketPtr) inputStream, &buffer[bufferLength], importBufferMaxLength - bufferLength, (Err*)&err);
				if (err) ErrThrow(false);
				bufferLength += charsRead;
				buffer[bufferLength] = nullChr;
				
			// stop at blank line by itself or EOF	
			} while (buffer[0] != crChr && buffer[0] != nullChr);	
			
			// We've now parsed the MIME header.  Preamble, segments, and postamble below.
		} // end of MIME parser
			
		do {
			// find the boundary and remove it, along with any header info in the body part
			if (*boundaryString != nullChr)
			{
				// Keep reading until we find a boundary
				while (buffer[0] != nullChr && StrNCompare(buffer, boundaryString, StrLen(boundaryString)) != 0)
				{
					err = ReadThroughCRLF(inputStream, buffer, &bufferLength);
					if (err) ErrThrow(false);
				}
				
				// Remove the boundary by removing all text until the end of the line.
				err = ReadThroughCRLF(inputStream, buffer, &bufferLength);
				if (err) ErrThrow(false);
				
				while (buffer[0] != nullChr && buffer[0] != crChr)
				{
					err = ReadThroughCRLF(inputStream, buffer, &bufferLength);
					if (err) ErrThrow(false);
				}
				err = ReadThroughCRLF(inputStream, buffer, &bufferLength);
				if (err) ErrThrow(false);
			}
			
			// could be that everything was header, and we're out of data.
			// weird error, but handle it.
			if (bufferLength == 0)
			{
				err = exgErrBadData;
				ErrThrow(false);
			}
			
			
			addCr = 0;
			while (bufferLength > 0 &&
				(*boundaryString == nullChr || StrNCompare(buffer, boundaryString, StrLen(boundaryString)) != 0))
			{
				// find CR or end of buffer
				nextCrChr = StrChr(buffer, crChr);
				if (nextCrChr != NULL)
					charsToWrite = nextCrChr - buffer;
				else
					charsToWrite = bufferLength;
				
				// if we're going to overflow record, close it out (leave room for terminating null)
				if (newRecordSize + charsToWrite + addCr > memoMaxLength)
				{
					// since we try to stop parsing at each CR, and most records from other sources (MIME)
					// should have a CR at least every 76 characters, we probably don't have to worry about
					// word wrap.  Still, beaming a lot of just plain text could break records on random
					// boundaries...
					MemoImportFinishRecord(dbP, indexNew, &newRecordH, &newRecordSize, inputStream);
					addCr = 0;
				}
				
				// Make a record if we need one
				if (newRecordH == NULL)
				{
					indexNew = dmMaxRecordIndex;
					newRecordH = DmNewRecord(dbP, (WordPtr)&indexNew, bufferLength);
					if (newRecordH == 0)
						ErrThrow(false);
					newRecordSize = 0;
				}
				
				// Write the buffer out to the record
				newHandle = DmResizeRecord(dbP, indexNew, newRecordSize + charsToWrite + addCr);
				if (newHandle)
					newRecordH = newHandle;
				else
					ErrThrow(true);
				
				newRecordP = MemHandleLock(newRecordH);
				if (addCr != 0)
					DmWrite(newRecordP, newRecordSize++, "\n", 1);
				DmWrite(newRecordP, newRecordSize, buffer, charsToWrite);
				newRecordSize += charsToWrite;
				MemHandleUnlock(newRecordH);
				
				// Remove the chars written so we can read more into the buffer
				if (nextCrChr != NULL)
				{
					if (charsToWrite < importBufferMaxLength-1)
					{
						MemMove(buffer, nextCrChr+2, bufferLength-(charsToWrite+2));	// delete LF
						bufferLength -= charsToWrite+2;
					}
					else
					// CR/LF was split by end of buffer, so DON'T delete the CR, catch it next time 'round
					{
						MemMove(buffer, nextCrChr, bufferLength-(charsToWrite));		// don't delete CR or LF
						bufferLength -= charsToWrite;
						nextCrChr = NULL;
					}
				}
				else
					buffer[bufferLength = 0] = nullChr;
				
				// Now read more
				charsRead = ExgReceive((ExgSocketPtr) inputStream, &buffer[bufferLength], importBufferMaxLength - bufferLength, (Err*)&err);
				if (err) ErrThrow(true);
				bufferLength += charsRead;
				buffer[bufferLength] = nullChr;
				
				if (nextCrChr != NULL)
					addCr = 1;
				else
					addCr = 0;
			}	// end of segment parser

			MemoImportFinishRecord(dbP, indexNew, &newRecordH, &newRecordSize, inputStream);

			// Now that the record is imported check if we need to import any more
			
			// Stop if there isn't any more input
			if (bufferLength == 0)
				break;
			
			// Stop if the boundary is followed by "--"
			if ((*boundaryString != nullChr)
				&& bufferLength >= StrLen(boundaryString) + 2
				&& StrNCompare(&buffer[StrLen(boundaryString)], "--", 2) == 0)
				break;
				
		} while (true);	// end of segment parser
	}	// end of Try
	
	ErrCatch(inErr)
		{
		// Remove the incomplete record
		if (inErr)
			DmRemoveRecord(dbP, indexNew);
		
		ErrThrow(err ? err : exgMemError);
		} ErrEndCatch

	return false;
}



/************************************************************
 *
 * FUNCTION: MemoExportMime
 *
 * DESCRIPTION: Export a record as a Imc Mime record
 *
 * PARAMETERS: 
 *			dbP - pointer to the database to export the records from
 *			index - the record number to export
 *			recordP - whether the begin statement has been read
 *			outputStream - pointer to where to export the record to
 *			outputFunc - function to send output to the stream
 *			writeUniqueIDs - true to write the record's unique id
 *
 * RETURNS: nothing
 *
 *	REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	8/6/97	Initial Revision
 *
 *************************************************************/

void MemoExportMime(DmOpenRef dbP, Int index, MemoDBRecordType * recordP, 
	const VoidPtr outputStream, const PutStringF outputFunc, Boolean writeUniqueIDs, 
	Boolean outputMimeInfo)
{
	CharPtr c;
	CharPtr eolP;
	ULong len;
	Err err;


	// Write out all of the memo.  All linefeeds must be replaced with CRLF combos.
	c = &recordP->note;
	
	if (outputMimeInfo)
		{
		if (!ImcStringIsAscii(c))
			PutString(outputStream, "Content-Type: Text/plain; charset=ISO-8859-1" crlf);
		
		PutString(outputStream, crlf);
		}
	
	while (*c != '\0')
		{
		eolP = StrChr(c, linefeedChr);
		if (eolP)
			{
			len = ExgSend((ExgSocketPtr) outputStream, c, eolP - c, &err);
			
			// If the bytes were not sent throw an error.
			if (len == 0 && (eolP - c) > 0)
				ErrThrow(err);
				
			outputFunc(outputStream, crlf);
			c = eolP + sizeofchar(linefeedChr);
			}
		else if (*c != '\0')
			{
			eolP = StrChr(c, '\0');
			len = ExgSend((ExgSocketPtr) outputStream, c, eolP - c, &err);
			
			// If the bytes were not sent throw an error.
			if (len == 0 && (eolP - c) > 0)
				ErrThrow(err);
				
			c = eolP;
			}
		}
	outputFunc(outputStream, crlf);	// always end with an extra crlf
}
