/***********************************************************************
 *
 *	 Copyright (c) 1994-1999 3Com Corporation or its subsidiaries.
 *   All rights reserved.
 *
 * PROJECT:  Touchdown
 * FILE:     MemRsc.c
 * AUTHOR:   Roger Flores: June 9, 1995
 *
 * DECLARER: Memo
 *
 * DESCRIPTION:
 *	  The list of resources are stored here.
 *
 **********************************************************************/

#include <BuildRules.h>
//#include <Pilot.h>

// RESOURCE_FILE_PREFIX is now defined in Pilot:Incs:BuildRules.h based on LANGUAGE.

char *AppResourceList[] = {
	":Rsc:"RESOURCE_FILE_PREFIX"MemoDetails.rsrc", 
	":Rsc:"RESOURCE_FILE_PREFIX"MemoEdit.rsrc",
	":Rsc:"RESOURCE_FILE_PREFIX"MemoList.rsrc", 
	":Rsc:"RESOURCE_FILE_PREFIX"MemoMisc.rsrc", 
	":Rsc:"RESOURCE_FILE_PREFIX"MemoPrefer.rsrc", 
	":Rsc:"RESOURCE_FILE_PREFIX"MemoDelete.rsrc", 
	":Rsc:"RESOURCE_FILE_PREFIX"MemoApp.rsrc", 
	""
	};
