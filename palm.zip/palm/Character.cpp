class Character {
  static boolean isSpace(WChar c) {
    return (c == ' ');
  }
}
