#!/bin/perl

open(F, "people.txt") || die $!;
@people = <F>;
close(F);

foreach $person (@people) {
    `mkdir $person`;
    `chmod 777 $person`;
}
